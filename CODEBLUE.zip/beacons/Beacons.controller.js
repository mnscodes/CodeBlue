sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, MessageToast, Fragment, Controller, Filter, JSONModel) {
	"use strict";

	var CController = Controller.extend("beacons.Beacons", {

		onInit: function(){
		    
	this.getQuery();
		var oText = {
			"beaconId": "",
			"locName": "",
			"xcord": "",
			"ycord": "",
			"extra1": "",
			"extra2": "",
			"extra3": "",
			"extra4": ""
		};
		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(oText);
		this.getView().setModel(oModel, "Beacon");
	},

	getQuery: function() {
		var sUrl = "https://iisdemo1a7eac59ae.hana.ondemand.com/iisdemo1/?action=getMap";
		var oModel = new sap.ui.model.json.JSONModel(sUrl, true);
		this.getView().setModel(oModel);
	},
			 
		
			/*	var modelName = new sap.ui.model.json.JSONModel("https://iisdemo1a7eac59ae.hana.ondemand.com/iisdemo1/?action=getMAP&$format=json");
			    var otable = this.getView().byId("__table0");
			    otable.setModel(modelName);
			 	},*/
        onOrientationChange: function(oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {duration: 5000});
		},

		onPressNavToDetail : function(oEvent) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack : function() {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack : function() {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster : function() {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},
		
		onPressGoToMaster1 : function() {
			this.getSplitAppObj().toMaster(this.createId("master3"));
		},

		onListItemPress : function(oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn : function(oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {duration: 5000});
		},

		getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		},
	onBeaconDelete: function(oEvent)
	{
	    
	  	var oSelectedItem = this.getView().byId(oEvent.getParameter("id")).getBindingContext().getProperty();
	 
		var sUrl =
			"https://iisdemo1a7eac59ae.hana.ondemand.com/iisdemo1/?action=DeleteSingleMapByBeaconId&beaconId="
			+ oSelectedItem.beaconId;
		var request = new XMLHttpRequest();
		request.open("GET", sUrl, true);
		request.send(null);
		var successMsg = "Beacon Details Deleted";
		sap.m.MessageToast.show(successMsg);
		this.getQuery();
		this.getView.getModel().refresh(true);
	},
	
	onBeaconUpdate: function(oEvent)
	{
	    
	    /*var selItems = this.view.*/
	   /* var temp = this.getView().*/
	   /* sap.ui.commons.MessageBox.alert("Hello World from MessageBox.alert()!");*/
    var oSelectedItem = this.getView().byId(oEvent.getParameter("id")).getBindingContext().getProperty();
     
		var sUrl =
			"https://iisdemo1a7eac59ae.hana.ondemand.com/iisdemo1/?action=UpdSingleMapByBeaconId&beaconId=" + oSelectedItem.beaconId +
			"&locName=" + oSelectedItem.locName + "&xcord=" + oSelectedItem.xcord + "&ycord=" + oSelectedItem.ycord + "&extra4=" + oSelectedItem.extra4 +
			"&extra3=" + oSelectedItem.extra3 + "&extra2=" + oSelectedItem.extra2 + "&extra1=" + oSelectedItem.extra1;
		var request = new XMLHttpRequest();
		request.open("GET", sUrl, true);
		request.send(null);
		var successMsg = "Beacon Details Updated";
		sap.m.MessageToast.show(successMsg);
		this.getQuery();
		this.getView.getModel().refresh(true);
		 
	//	this.getview.byId("id").getModel().refresh(true);
		 
	},
	
	onBeaconInsert: function(){
		var oBeacon = this.getView().getModel("Beacon").getData();
		var sUrl =
			"https://iisdemo1a7eac59ae.hana.ondemand.com/iisdemo1/?action=defineArea&beaconId=" + oBeacon.beaconId +
			"&locName=" + oBeacon.locName + "&xcord=" + oBeacon.xcord + "&ycord=" + oBeacon.ycord + "&extra4=" + oBeacon.extra4 +
			"&extra3=" + oBeacon.extra3 + "&extra2=" + oBeacon.extra2 + "&extra1=" + oBeacon.extra1;
		var request = new XMLHttpRequest();
		request.open("GET", sUrl, true);
		request.send(null);
		var successMsg = "Beacon Added";
		sap.m.MessageToast.show(successMsg);
		oBeacon.beaconId="";
		oBeacon.locName="";
		oBeacon.xcord="";
		oBeacon.ycord="";
		oBeacon.extra1="";
		oBeacon.extra2="";
		oBeacon.extra3="";
		oBeacon.extra4="";
		this.getView().getModel("Beacon").setData(oBeacon);
		this.getQuery();
	},
	
	onAdd : function(oEvent) {
				var myView1 = sap.ui.view({
					type:sap.ui.core.mvc.ViewType.XML,
					viewName:"beacons.AddBeacon"
				});
				
				
				
	}

	});


	return CController;

});