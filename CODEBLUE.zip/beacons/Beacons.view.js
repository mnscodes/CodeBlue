    sap.ui.jsview("beacons.Beacons", {
    
    	/** Specifies the Controller belonging to this View. 
    	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
    	* @memberOf codeblue.detail
    	*/ 
    	getControllerName : function() {
    		return "beacons.Beacons";
    	},
    
    	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
    	* Since the Controller is given to this method, its event handlers can be attached right away. 
    	* @memberOf codeblue.detail
    	*/ 
    	createContent:function(){
    	    
    	  //  var oController = this.getController();
			/*var oMatrix = new sap.ui.commons.layout.MatrixLayout({
				id : 'matrix4',
				layoutFixed : true,
				width : '1000px',
				columns : 5,
				widths : ['150px', '250px', '200px', '200px', '200px']});
    	    
    	   var oButton1 =  new sap.m.Button({
    	            id : 'B_reset',
					text: "Go to Page 2",
					press: function () {
						// navigate to page2
						//app.to("page2");
					}
				});*/
	     	//var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
		  var divider1 = new sap.ui.commons.HorizontalDivider();
			//oMatrix.createRow(oCell);  horizontal divider */
			//oMatrix.createRow(oButton1);
			var oBar = new sap.m.Bar( {  
		        design:sap.m.BarDesign.Header,
		        //design: sap.m.BarDesign.SubHeader,
	          contentLeft : [new sap.m.Button({
					icon: "sap-icon://nav-back",
					press: function(){
						sap.ui.getCore().byId("codeblueapp").to("idEntry1");
					}
				})],
	         
	          contentMiddle : [ new sap.m.Label( {  
	          text :"Indoor Navigation Configuration",    
	          textAlign : "Left",  
	          design : "Bold" 
	            }) ], 
	     
	         contentRight : []
	        }); 
	        var vbox = new sap.m.VBox(['vbox1']);
	        var Hospital = new sap.ui.commons.Panel('Hospital',[new sap.ui.commons.layout.BorderLayout({
	        	id: "hospitallayout", // sap.ui.core.ID
	        	rtl: false, // boolean
	        	width: "100%", // sap.ui.core.CSSSize
	        	height: "100%", // sap.ui.core.CSSSize
	        	tooltip: undefined, // sap.ui.core.TooltipBase
	        	customData: [], // sap.ui.core.CustomData
	        	dependents: [], // sap.ui.core.Control, since 1.19
	        	top: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	begin: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	center: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	end: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	bottom: undefined // sap.ui.commons.layout.BorderLayoutArea
	        })
	        ]);
	       
	        Hospital.setTitle(new sap.ui.core.Title({text:"Hospital Map Configuration"}));
	         var MobileApp = new sap.ui.commons.Panel('MobielApp',[new sap.ui.commons.layout.BorderLayout({
	        	id: "Mobilelayout", // sap.ui.core.ID
	        	rtl: false, // boolean
	        	width: "100%", // sap.ui.core.CSSSize
	        	height: "20rem", // sap.ui.core.CSSSize
	        	tooltip: undefined, // sap.ui.core.TooltipBase
	        	customData: [], // sap.ui.core.CustomData
	        	dependents: [], // sap.ui.core.Control, since 1.19
	        	top: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	begin: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	center: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	end: undefined, // sap.ui.commons.layout.BorderLayoutArea
	        	bottom: undefined // sap.ui.commons.layout.BorderLayoutArea
	        })
	        ]);
	         MobileApp.setTitle(new sap.ui.core.Title({text:"Mobile Application Configuration"}));
	         Hospital.setCollapsed(true);
	         MobileApp.setCollapsed(true);
	        vbox.addItem(Hospital);
	        vbox.addItem(MobileApp);
	        var splitApp = new sap.m.SplitApp("splitApp",{mode : sap.m.SplitAppMode.ShowHideMode});
	        var master = sap.ui.view({id:"master", viewName:"beacons.MasterView", type:sap.ui.core.mvc.ViewType.JS});
            splitApp.addMasterPage(master);
            var detail = sap.ui.view({id:"detail", viewName:"beacons.DetailView", type:sap.ui.core.mvc.ViewType.JS});
            splitApp.addDetailPage(detail);
            Hospital.addContent(splitApp);
	        
	        
    
			
	var page1 = new sap.m.Page("page1", {
				title: "Code Blue",
				content:[ divider1,oBar,vbox],
				showNavButton: false
				
			});
			return page1;
	
    	}
    });


/*<!--<mvc:View
	xmlns:mvc="sap.ui.core.mvc"
	xmlns:custom="http://schemas.sap.com/sapui5/extension/sap.ui.core.CustomData/1"
	controllerName="beacons.Beacons"
	xmlns:l="sap.ui.layout"
	xmlns:c="sap.ui.core"
	xmlns="sap.m"
	xmlns:m="sap.m"
	xmlns:u="sap.ui.unified"
	xmlns:t="sap.ui.table"
	xmlns:table="sap.ui.table" >
	
	
	
	<Page title="Code Blue" showHeader="true" enableScrolling="true"
            class="sapUiContentPadding">
            <customHeader>
                  <Bar>
                        <contentLeft>
                              <Image src="img/SAP.jpg"></Image>
                        </contentLeft>
                        <contentMiddle>
                              <Label id="titleText" class="headingText" text="Code Blue"
                                    design="Bold" />
                        </contentMiddle>
                        <contentRight>
                              <Button icon="sap-icon://home" id="btnHome" press="onBtnHome"
                                    text="Home" />
                        </contentRight>
                  </Bar>
            </customHeader>
            
            <Page id="detail23" title="Indoor Navigation System Configuration" class="sapUiContentPadding">
				<content>
					<!--<RadioButton id="r1" groupName="GroupA" text = "Mobile Application Configuration" selected = "true"/>
					<RadioButton id="r2" groupName="GroupA" text = "Hospital Map Configuration" />-->
					<Panel expandable="true" expanded="false" class="sapUiResponsiveMargin" headerText="Hospital Map Configuration">
					    <SplitApp id="SplitAppDemo" initialDetail="detail" initialMaster="master" orientationChange="onOrientationChange">
					        <detailPages>
					            <Page id="detail" title="Map View" class="sapUiStdPage">
				                    <content>
					                    <l:VerticalLayout  class="sapUiContentPadding" width="100%">
		                                      <l:content>
			                                       <HBox><Label text="Place your image here" /></HBox>
		                                      </l:content>
	                                    </l:VerticalLayout>
	                                </content>
			                    </Page>
			                    <Page id="detail2" title="List of Beacons" class="sapUiStdPage" showNavButton="true" navButtonText="Back" navButtonPress="onPressDetailBack">
				                    <content>
			                            <HBox><Label text="Place your image here" /></HBox>
	                                    <table:Table id="tblAppraisals" table:selectionMode="none" rows="{/AreaMap}" seletionMode="sap.ui.table.SelectionMode.none">
                                            <table:columns>
                                                <table:Column>
                                                        <Label text="id" />
                                                            <table:template>
                                                                <Text editable="true" text="{id}"></Text>
                                                            </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Beacon" />
                                                            <table:template>
                                                                <Text editable="true" text = "{beaconId}"></Text>     
                                                            </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Location name" />
                                                            <table:template>
                                                                <Text editable="true" text="{locName}"></Text>
                                                            </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="X Cord" />
                                                        <table:template>
                                                                <Text editable="true" text="{xcord}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Y Cord" />
                                                        <table:template>
                                                        <Text editable="true" text="{ycord}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Extra1" />
                                                        <table:template>
                                                        <Text editable="true" text="{extra1}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Extra2" />
                                                        <table:template>
                                                        <Text editable="true" text="{extra2}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Extra3" />
                                                        <table:template>
                                                        <Text editable="true" text="{extra3}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                <table:Column>
                                                        <Label text="Extra4" />
                                                        <table:template>
                                                        <Text editable="true" text="{extra4}"></Text>
                                                        </table:template>
                                                </table:Column>
                                                </table:columns>
                                            </table:Table>
                                        <HBox>
                                        <Button class="buttonsud" activeIcon="" icon="sap-icon://save" id="__button3"  text="Update"/>
									    <Button class="buttonsud" activeIcon="" icon="sap-icon://delete" id="__button4" text="Delete"/>
								        </HBox>
                                    </content>
			                    </Page>
	
					        </detailPages>
					        <!--*********************************master pages***********************-->
		                    <masterPages>
		                        <Page id="master" title="Menu" icon="sap-icon://action" class="sapUiStdPage">
				                    <content>
					                    <List itemPress="onListItemPress">
						                    <items>
							                    <StandardListItem title="Map" type="Active" custom:to="detail"/>
							                    <StandardListItem title="List" type="Active" custom:to="detail2"/>
							                 </items>
					                    </List>
				                    </content>
			                    </Page>
		                    </masterPages>
					    </SplitApp>
					
                    </Panel>
                    <Panel expandable="true" expanded="false" class="sapUiResponsiveMargin" headerText="Mobile Map Configuration">
                    </Panel>	
				</content>
			</Page>
			<footer>
                <Bar>
                </Bar>
             </footer>
      </Page>
</mvc:View>-->*/