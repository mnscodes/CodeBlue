sap.ui.jsview("beacons.DetailView", {

	getControllerName : function() {
    		return "beacons.Beacons";
    	},
    		createContent:function init(){

	//	olistCatgery.addColumn(arguments);
	//	olistCatgery.addColumn('list');
					  
	var paged = new sap.m.Page("paged", {
				title: "Code Bl",
				content:[],
				showNavButton: false
				
			});
			return paged;
	
    	}
});