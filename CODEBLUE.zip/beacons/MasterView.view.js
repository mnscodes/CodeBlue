sap.ui.jsview("beacons.MasterView", {

	getControllerName : function() {
    		return "beacons.Beacons";
    	},
    		createContent:function init(){
var olistCatgery1 =  new sap.m.List("list", {
			includeItemInSelection : true,
			inset : true
		});
		var oColumn1 = new sap.m.Column("col1","column1");
		olistCatgery1.addColumn(oColumn1);
	//	olistCatgery1.addColumn('list');
					  
	var pagem = new sap.m.Page("pagem", {
				title: "Code Bl",
				content:[],
				showNavButton: false
				
			});
			return pagem;
	
    	}
});