sap.ui.controller("codeblue.Register", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf codeblue.Register
*/
	onInit: function() {
//rest call
		//var currentView = this;
		var regdata = {};
		var modelName = new sap.ui.model.json.JSONModel(regdata);
		this.getView().setModel(modelName,"PatientRegistration");
		
	},



	onBeforeRendering: function() {

},


submitdata : function(data)
{
    data.Patient_Id = data.Name;
    //alert(JSON.stringify(data));
    
    $.ajax({
        			        url : "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient",
        			        data : JSON.stringify(data),
        			        method: "POST",
        			        accept : "application/json",
        			        contentType :"application/json",
        			        success:function(data)
        			        {
        			           //alert ("saved sucssusfully" + data);
        			        },
        			        failure : function()
        			        {
        			            alert("failed");
        			        }
        			     });
},


openDialog : function() {
	var oDialog1 = new sap.ui.commons.Dialog();
	oDialog1.setTitle("Saved Successfully");
	var oText = new sap.ui.commons.TextView({text: "Patient Registered "});
	oDialog1.addContent(oText);
	oDialog1.addButton(new sap.ui.commons.Button({text: "OK", press:function(){oDialog1.close();}}));
	oDialog1.open();
}

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf codeblue.Register
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf codeblue.Register
*/
//	onExit: function() {
//
//	}

});