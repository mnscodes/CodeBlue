	sap.ui.jsview("codeblue.Register", {
	
		/** Specifies the Controller belonging to this View. 
		* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
		* @memberOf codeblue.Register
		*/ 
		getControllerName : function() {
			return "codeblue.Register";
		},
	
		/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
		* Since the Controller is given to this method, its event handlers can be attached right away. 
		* @memberOf codeblue.Register
		*/ 
		createContent:function(){
		    
		    
		   	var ologo = new sap.m.Image({  
	          src : "img/cblue.jpg"     
	            });
	            
	            
	            var saplogo =new sap.m.Image({  
	          src : "img/SAP.jpg"     
	            });
	            ologo.addStyleClass("codebluelogo");
	
		 var oBar = new sap.m.Bar( {  
		        design:sap.m.BarDesign.Header,
		        //design: sap.m.BarDesign.SubHeader,
	          contentLeft : [saplogo],  
	         
	          contentMiddle : [ ologo ], 
	     
	         contentRight : [new sap.m.Button({
					icon: "sap-icon://nav-back",
					press: function(){
						sap.ui.getCore().byId("codeblueapp1").to("idEntry1");
					}
				})]  
	        }); 
	        
		   
		   
		   
		   
		    
			
			
			
			var oController = this.getController();
			var oMatrix = new sap.ui.commons.layout.MatrixLayout({
				id : 'matrix4',
				layoutFixed : true,
				width : '1000px',
				columns : 5,
				widths : ['150px', '250px', '200px', '200px', '200px'] });
	oMatrix.addStyleClass("SapUiSizeCompact");
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({
				colSpan: 5 });
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Contact Data', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oLabel = new sap.m.Label({
				id : 'L-Name',
				text : 'Name' });
			var oTF = new sap.m.Input({
				id : 'TF-Name',
				tooltip : 'Name',
				editable : true,
				value : "{PatientRegistration>/Name}",
				width : '350px' });
			oLabel.setLabelFor(oTF);
			
			var oLabel12 = new sap.m.Label({
				id : 'email_Name',
				text : 'Email ID' });
			var oTF12 = new sap.m.Input({
				id : 'emaill_Name',
				tooltip : 'Email',
				editable : true,
				value : "{PatientRegistration>/emailid}",
				width : '300px' });
			oLabel12.setLabelFor(oTF12);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
		var	oCell2 = new sap.ui.commons.layout.MatrixLayoutCell();
		var	oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({
				rowSpan : 8},{colSpan : 100});
			var oImg = new sap.ui.commons.Image({
				id : 'IMG-Pic',
				src : 'codeblue/img/patient.png',
				alt : 'Face',
				tooltip : 'Picture of Contact',
				height : '200px' });
			oCell1.addContent(oImg);
			oMatrix.createRow(oLabel, oTF, oCell,oCell1);
			oMatrix.createRow(oLabel12, oTF12);
			
			
			var	oCellu = new sap.ui.commons.layout.MatrixLayoutCell({
				rowSpan : 5},{colSpan:2});
			var	obuttonI = new sap.m.Button({
				id : 'ImaButton',
				text : 'Upload image' });
				
					oCellu.addContent(obuttonI);
				
		    oLabel = new sap.m.Label({
				id : 'L-F-Name',    
				text : 'Contact Number' });
	
			oTF = new sap.m.Input({
				id : 'TF-F-Name',
				tooltip : 'Contact Number',
				editable : true,
				value : "{PatientRegistration>/Contact_Number}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);
	
			oLabel = new sap.m.Label({
				id : 'L-Street',
				text : 'Address' });
	
			oTF = new sap.m.TextArea({
				id : 'TF-Street',
				tooltip : 'Address',
				editable : true,
				value : "{PatientRegistration>/fullAddress}",
				width : '355px' });
			oLabel.setLabelFor(oTF);
			var oTF2 = new sap.m.Input({
				id : 'TF-HNum',
				tooltip : 'House Number',
				editable : true,
				//value : '10',
				width : '50px',
				maxLength : 5 });
	
			//multiple controls within one cell
			/*oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell.addContent(oTF);
			oCell.addContent(oTF2);*/
			oMatrix.createRow(oLabel,oTF );
	
		/*	oLabel = new sap.m.Label({
				id : 'L-City',
				text : 'Height' });
	
			oTF = new sap.m.Input({
				id : 'TF-Height',
				tooltip : 'Height',
				editable : true,
				value : "{PatientRegistration>/Hieght}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF,oCell2);
			*/
			
		/*	oLabel = new sap.m.Label({
				id : 'Weight',
				text : 'Weight' });
	
			oTF = new sap.m.Input({
				id : 'TF-City',
				tooltip : 'Weight',
				editable : true,
				value :  "{PatientRegistration>/Weight}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);*/
	
	/*
			oLabel = new sap.m.Label({
				id : 'L-Country',
				text : 'Blood group' });
	
		var	oCBBloodgroup = new sap.m.Select({
				id : 'TF-Country',
				tooltip : 'Country',
				enabled : true,
			    //value :  "{PatientRegistration>/Blood_Group}",
				width : '300px' });
			oLabel.setLabelFor(oCBBloodgroup);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI1',
				text : 'B+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI2',
				text : 'A+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI5',
				text : 'AB+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI7',
				text : 'AB-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI6',
				text : 'B-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI8',
				text : 'A-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI3',
				text : 'O+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI4',
				text : 'O-' });
			oCBBloodgroup.addItem(oItem);
			oMatrix.createRow(oLabel, oCBBloodgroup);
	*/
			oLabel = new sap.m.Label({
				id : 'L-Date',
				text : 'Date of birth' });
			oDate1 = new sap.m.DatePicker({
				id : 'DP-Date',
				tooltip : 'Date of Birth',
				editable : true
			//	yyyymmdd :  "{PatientRegistration>/DOB}"
				});
			oLabel.setLabelFor(oDate1);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oLabel2 = new sap.ui.commons.Label({
				id : 'L-URL',
				text : 'URL for picture',
				visible : false });
				
			oMatrix.createRow(oLabel, oDate1, oCell, oLabel2);
	
			oLabel = new sap.m.Label({
				id : 'L-Gender',
				text : 'Gender' });
			var oRBG = new sap.ui.commons.RadioButtonGroup({
				id : 'RBG-Gender',
				tooltip : 'Gender',
				columns : 2,
				editable : true,
				select : function() {
				    var gender =oRBG.getSelectedItem().getText();
				    var genderctr = sap.ui.getCore().byId("gender");
				    
				    genderctr.setValue(gender.charAt(0));
				   // alert (gender);
				    
				}
				   // alert('Gender ' + oRBG.getSelectedItem().getText());}
			});
			oTF1 = new sap.m.Input({
				id : 'gender',
				visible : false,
				value : "{PatientRegistration>/Gender}",
				width : '300px' });
			oLabel.setLabelFor(oTF1);
			
			var oItem = new sap.ui.core.Item({
				id : 'RB-Male',
				text : 'Male',
				//tooltip : 'Gender: male',
				key : 'male' });
			oRBG.addItem(oItem);
			oItem = new sap.ui.core.Item({
				id : 'RB-Female',
				text : 'Female',
				tooltip : 'Gender: female',
				key : 'female' });
			oRBG.addItem(oItem);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
		    
			oTF = new sap.m.Input({
				id : 'TF-URL',
				tooltip : 'URL for picture',
				visible : false,
				value : 'images/face.png',
				width : '100%',
				change : function(oEvent){
					var oCore = sap.ui.getCore();
					var oTF = oEvent.oSource;
					var oIMG = oCore.getControl("IMG-Pic");
					oIMG.setSrc( oTF.getValue() );}
				});
			oLabel2.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oRBG, oCell, oTF, oTF1);
			
			//pulse
			var oTF2 = new sap.m.Input({
				id : 'TF-high',
				tooltip : 'House Number',
				editable : true,
				//value : '10',
				width : '50px',
				maxLength : 5 });
	
			//multiple controls within one cell
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell.addContent(oTF);
			oCell.addContent(oTF2);
			//oMatrix.createRow(oLabel, oCell);
	
// 		
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
	
			var oRtt = new sap.ui.commons.RichTooltip(
					'Rtt-Change',
					{title: 'Reset Button',
					text:"If you like to Reset this data press this button. If not, don't press it."
					});
				oRtt = new sap.ui.commons.RichTooltip(
					'Rtt-Save',
					{title: 'Save Button',
					//imageSrc: '../images/save-icon.png',
					//imageSrc: 'images/save-icon.gif',
						width : '10em',
					text:"Press this button to save the value. But as long as we don't know where to save the data is not really saved."
					});
			var oButton2 = new sap.m.Button({
				id : 'B-Save',
				tooltip : oRtt,
				width : '10em',
				text : 'Save',
				//icon : '../images/save-icon.png',
				enabled: true,
				press : function(){
					//var x = sap.ui.getCore().getModel("abcd");
				var x = this.getModel("PatientRegistration");
					var jsonData = x.getData();
					
					//alert(JSON.stringify(jsonData));
					//alert(oCB1doctor.getSelectedItem().getText());
					jsonData.Program_Name = oCBProgram.getSelectedItem().getText();
					jsonData.Doctor_Name = oCB1doctor.getSelectedItem().getText();
					jsonData.Blood_Group = oCBBloodgroup.getSelectedItem().getText();
				//	jsonData.DOB = oDate1.getSelectedItem().getText();
					
					oController.submitdata(jsonData);
					oController.openDialog();
					/*var x = this.getModel("patientregdata");
					var jsonData = x.getData();
					alert(JSON.stringify(jsonData));*/
					}
				}); 
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Medical Details', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			
			
			
			
			
			
				oLabel = new sap.m.Label({
				id : 'L-City',
				text : 'Height' });
	
			oTF = new sap.m.Input({
				id : 'TF-Height',
				tooltip : 'Height',
				editable : true,
				value : "{PatientRegistration>/Hieght}",
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF,oCell2);
			
			
				oLabel = new sap.m.Label({
				id : 'Weight',
				text : 'Weight' });
	
			oTF = new sap.m.Input({
				id : 'TF-City',
				tooltip : 'Weight',
				editable : true,
				value :  "{PatientRegistration>/Weight}",
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);
			
			
			
			oLabel = new sap.m.Label({
				id : 'L-Country',
				text : 'Blood group' });
	
		var	oCBBloodgroup = new sap.m.Select({
				id : 'TF-Country',
				tooltip : 'Country',
				enabled : true,
			    //value :  "{PatientRegistration>/Blood_Group}",
				width : '150px' });
			oLabel.setLabelFor(oCBBloodgroup);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI1',
				text : 'B+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI2',
				text : 'A+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI5',
				text : 'AB+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI7',
				text : 'AB-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI6',
				text : 'B-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI8',
				text : 'A-' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI3',
				text : 'O+' });
			oCBBloodgroup.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'LI4',
				text : 'O-' });
			oCBBloodgroup.addItem(oItem);
			oMatrix.createRow(oLabel, oCBBloodgroup);
	
			
			
			
			
			
			oLabel = new sap.m.Label({
				id : 'pulse',
				text : 'Pulse rate' });
				
			/*oLabel1 = new sap.m.Label({
				id : 'pulse-',
				text : '_' });*/
	
			oTF = new sap.m.Input({
				id : 'TF-pulse',
				tooltip : 'pulse',
				editable : true,
				//value: 'Hauptstraße',
				width : '150px' });
				
				oLabel.setLabelFor(oTF);
		
				
		/*	oTf2 = new sap.m.Input({
				id : 'TF-pulse2',
				tooltip : 'Street',
				editable : true,
				//value : 'Hauptstraße',
				width : '150px' });	*/
		
		oCell = new sap.ui.commons.layout.MatrixLayoutCell();
        oCell.addContent(oTF);
      //  oCell.addContent(oLabel1);
        //oCell.addContent(oTF2);
        oMatrix.createRow(oLabel,oCell);



			oLabel = new sap.ui.commons.Label({
				id : 'bp',
				text : 'BP' });
	
			
		/*	oLabel1 = new sap.m.Label({
				id : 'BP-',
				text : '_' });*/
	
			oTF = new sap.m.Input({
				id : 'TF-bp',
				tooltip : 'BP',
				editable : true,
				//value : 'Hauptstraße',
				width : '150px' });
				
				/*	oTF1 = new sap.m.Input({
				id : 'TF-bp1',
				tooltip : 'BP',
				editable : true,
				//value : 'Hauptstraße',
				width : '150px' });
				*/
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
             oCell.addContent(oTF);
             //oCell.addContent(oLabel1);
             //oCell.addContent(oTF1)
			oMatrix.createRow(oLabel,oCell);
			
		
		
		
// 	oMatrix.createRow(oLabel,oTF,oLabel2,oTf2);
			
			oLabel = new sap.m.Label({
				id : 'temprature',
				text : 'Temprture' });
	
			oTF = new sap.m.Input({
				id : 'TF-tempar',
				tooltip : 'Temprture',
				editable : true,
				//value : 'Hauptstraße',
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel,oTF);
			
		
			
			
			
			oLabel = new sap.m.Label({
				id : 'sleeping_hours',
				text : 'Sleeping hours' });
	
			oTF = new sap.m.Input({
				id : 'TF-sleep',
				tooltip : 'Street',
				editable : true,
				value : "{PatientRegistration>/SLEEPINGHOURS}",
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel,oTF);
						
			
			oLabel2 = new sap.ui.commons.Label({
				id : 'other_info',
				text : 'Other Information' });
	
			oTF2 = new sap.m.TextArea({
				id : 'tfoth',
				tooltip : 'Street',
				editable : true,
				value : "{PatientRegistration>/Health_Condition}",
				width : '100%',
				height : '150px'});
			oLabel2.setLabelFor(oTF2);
			oMatrix.createRow(oLabel2,oTF2 );
			
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Program Details', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);

			
			//program details
			
			oLabel = new sap.ui.commons.Label({
				id : 'prgram',
				text : 'Program Assigned' });
	
			var oCBProgram = new sap.m.Select({
				id : 'TF-prg1',
				enabled : true,
				width : '200px' });
			oLabel.setLabelFor(oCB);
			
			var oItemSelect = new sap.ui.core.Item({
			     //key : "{Name}",
                text : "{Name}",
                type :"Active"
        });  
        
        var modelProgram = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Program?$format=json");
			oCBProgram.setModel(modelProgram);
			oCBProgram.bindAggregation("items","/d/results",oItemSelect);
			
			oLabel1 = new sap.ui.commons.Label({
				id : 'doctor',
				text : 'Doctor Assigned' });
	
		var oCB1doctor = new sap.m.Select({
				id : 'dc1',
				editable : true,
				width : '200px' });
			oLabel1.setLabelFor(oCB);
			
			
			var oItemSelectD = new sap.ui.core.Item({
			     //key : "{Name}",
                text : "{Name}",
                type :"Active"
        });  
        
       
        var modelDoctor = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Doctor?$format=json");
			oCB1doctor.setModel(modelDoctor);
			oCB1doctor.bindAggregation("items","/d/results",oItemSelectD);
			
			
		/*	oLabel1 = new sap.m.Label({
				id : 'doctor',
				text : 'Doctor Assigned' });
			
			var oItem = new sap.ui.core.ListItem({
				id : 'dc2',
				text : 'Dr. Harry' });
			oCB1.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'dc3',
				text : 'Dr. Jack  ' });
			oCB1.addItem(oItem);
			var oItem = new sap.ui.core.ListItem({
				id : 'dc4',
				text : 'Program4' });
			oCB1.addItem(oItem);*/
	
	
			
			oMatrix.createRow(oLabel, oCBProgram, oLabel1, oCB1doctor);
			
			
			//program details
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Emergency Contact', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			
			var oLabel = new sap.m.Label({
				id : 'Le-Name',
				text : 'Name 1' });
			var oTF = new sap.m.Input({
				id : 'TFe-Name',
				tooltip : 'Name 1',
				editable : true,
				width : '200px' ,
			    value  : "{PatientRegistration>/emergency_contact1_name}"
			});
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({rowSpan : 7 });
			var oLabel1 = new sap.m.Label({
				id : 'Le-Number',
				text : 'Contact number' });
			var oTF1 = new sap.m.Input({
				id : 'TFe-Number',
				tooltip : 'Name 1',
				editable : true,
				width : '200px',
				value  : "{PatientRegistration>/Emergency_Contact_1}"
			    
			});
			oLabel1.setLabelFor(oTF1);
			oCell1.addContent(oLabel1);
			oMatrix.createRow(oLabel, oTF,oLabel1, oTF1 );
			
			
			var oLabel = new sap.m.Label({
				id : 'Le-EmerName',
				text : 'Name 2' });
			var oTF = new sap.m.Input({
				id : 'TFe-NameEm',
				tooltip : 'Name 2',
				editable : true,
				width : '200px',
			    value : "{PatientRegistration>/emergency_contact2_name}"
			});
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({rowSpan : 7 });
			var oLabel1 = new sap.m.Label({
				id : 'Le-EmerNumber',
				text : 'Contact number' 
			    
			});
			var oTF1 = new sap.m.Input({
				id : 'TFe-NumberE',
				tooltip : 'Name',
				editable : true,
				width : '200px',
				value : "{PatientRegistration>/Emergency_Contact_2}"
				});
			oLabel1.setLabelFor(oTF1);
			oCell1.addContent(oLabel1);
			oMatrix.createRow(oLabel, oTF,oLabel1, oTF1 );
			
			
			
			
			
			
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oButton1 = new sap.m.Button({
				id : 'B-reset',
				tooltip : oRtt,
				text : 'Reset',
				width : '10em',
				enabled : true,
				press : function(){
					var oCore = sap.ui.getCore();
					var oTF = oCore.getControl('TF-Name');
					oTF.setValue("");
					var oTF = oCore.getControl('emaill_Name');
					oTF.setValue("");
					var oTF = oCore.getControl('TF-F-Name');
					oTF.setValue("");
					var oTF = oCore.getControl('TF-Street');
					oTF.setValue("");
					oTF = oCore.getControl('TF-F-Name');
					oTF.setValue("");
					oTF = oCore.getControl('TF-Street');
					oTF.setValue("");
					oTF = oCore.getControl('TF-Height');
					oTF.setValue("");
					oTF = oCore.getControl('TF-Country');
					oTF.setValue("");
					var oCB = oCore.getControl('DP-Date');
					oCB.setValue("");
					var oDP = oCore.getControl('RBG-Gender');
					oTF.setValue("");
					var oTFL1 = oCore.getControl('TF-pulse');
					oTFL1.setValue("");
					var oTFL = oCore.getControl('TF-pulse2');
					oTFL.setValue("");
					var oTF = oCore.getControl('TF-bp');
					oTF.setValue("");
					var oTA = oCore.getControl('TF-bp1');
					oTA.setValue("");
					var oTA = oCore.getControl('TF-tempar');
					oTA.setValue("");
					var oTF = oCore.getControl('TF-sleep');
					oTF.setValue("");
					var oTF = oCore.getControl('tfoth');
					oTF.setValue("");
					var oTF = oCore.getControl('TFe-Name');
					oTF.setValue("");
					var oTF = oCore.getControl('TFe-Number');
					oTF.setValue("");
					var oTF = oCore.getControl('TFe-NameEm');
					oTF.setValue("");
					var oTF = oCore.getControl('TFe-NumberE');
					oTF.setValue("");
					var oTF1 = oCore.getControl('TF-City');
					oTF1.setValue("");
					TF-City
					
					oButton = oCore.getControl('B-Change');
					var oRtt = oCore.getControl('Rtt-Change');
					if( oButton.getText() == 'Change'){
						oButton.setText('Display');
						oRtt.setText("If you not like to change these data press this button. If you still want to change, don't press it.");
					} else{
						oButton.setText('Change');
						oRtt.setText("If you like to change these data press this button. If not, don't press it.");
					}
				}
				});
	
	
			oMatrix.createRow(oButton1, oButton2);
	
			// attach it to some element in the page
			//oMatrix.placeAt('sample4');
		    var page = new sap.m.Page("RegPage",{
		         press: function(){
		        	 sap.ui.getCore().byId("codeblueapp").to("idRegister1");
		             
		         },
		        content: [oMatrix,obuttonI]
		}); 
		    page.setCustomHeader(oBar);
		    page.addStyleClass("SapUiSizeCompact");
		    return page;
	
		 }
	
		});