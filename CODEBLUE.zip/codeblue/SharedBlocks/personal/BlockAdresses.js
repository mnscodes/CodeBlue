sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";

	var BlockAdresses = BlockBase.extend("sap.uxap.sample.SharedBlocks.personal.BlockAdresses", {
		metadata: {}
	});
	return BlockAdresses;
}, true);
