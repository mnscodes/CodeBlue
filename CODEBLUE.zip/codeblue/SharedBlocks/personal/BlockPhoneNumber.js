sap.ui.define(['sap/uxap/BlockBase'],
	function (BlockBase) {
		"use strict";

		var BlockPhoneNumber = BlockBase.extend("sap.uxap.sample.SharedBlocks.personal.BlockPhoneNumber", {
			metadata: {}
		});


		return BlockPhoneNumber;

	});
