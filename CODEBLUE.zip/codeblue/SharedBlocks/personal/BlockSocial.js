sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var BlockSocial = BlockBase.extend("sap.uxap.sample.SharedBlocks.personal.BlockSocial", {
		metadata: {}
	});


	return BlockSocial;

});
