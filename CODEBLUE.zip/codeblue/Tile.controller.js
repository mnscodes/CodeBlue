sap.ui.define(['jquery.sap.global', 'sap/ui/core/mvc/Controller'],
	function(jQuery, Controller) {
	"use strict";

	var PageController = Controller.extend("codeblue.Tile", {
		/*press : function(evt) {
			this.getView().getParent().to("idPatient1");
		},*/
		
		
		press : function(evt) {
			this.getView().getParent().to("idEntry1");
		}, 
		
		onBtnLogOut : function() {
			this.getView().getParent().to("idLogin1");
		}
	});

	return PageController;
});

