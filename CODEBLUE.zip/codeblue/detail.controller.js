sap.ui.controller("codeblue.detail", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf codeblue.detail
*/
	onInit: function() {
	     /*var patient_data = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient?$format=json");
	    var first_patient_data = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient?$format=json");
		this.getView().setModel(first_patient_data,"patientdetdata");*/
		
	    var json={};	
        var data = new sap.ui.model.json.JSONModel(json);
        data = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient?$format=json");
         this.getView().setModel(data,"patientdetdata2");
		
	},
	                 
	           				

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf codeblue.detail
*/
	onBeforeRendering: function() {
       var temp = this.getView().getModel("patientdetdata2");
       var first_patient_json=  temp.getProperty("/d/results/0");
       
        var path = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient";
		path = path +  "('" +  first_patient_json.Patient_Id + "')";
		path = path + "?$format=json";
        var fir_patient_details = new sap.ui.model.json.JSONModel(path);
        this.getView().setModel(fir_patient_details,"patientdetdata");
        
	}

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf codeblue.detail
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf codeblue.detail
*/
//	onExit: function() {
//
//	}

});