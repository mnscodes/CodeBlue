    sap.ui.jsview("codeblue.detail", {
    
    	/** Specifies the Controller belonging to this View. 
    	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
    	* @memberOf codeblue.detail
    	*/ 
    	getControllerName : function() {
    		return "codeblue.detail";
    	},
    
    	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
    	* Since the Controller is given to this method, its event handlers can be attached right away. 
    	* @memberOf codeblue.detail
    	*/ 
    	createContent:function(){
			
			
			
			var oBar = new sap.m.Bar( {  
		        design:sap.m.BarDesign.Header,
		        //design: sap.m.BarDesign.SubHeader,
	          contentLeft : [
	             /* new sap.m.Button({
					icon: "sap-icon://nav-back",
					press: function(){
						sap.ui.getCore().byId("codeblueapp").to("idEntry1");
					}
				})*/
				],  
	         
	          contentMiddle : [ new sap.m.Label( {  
	          text :"Patient Details",    
	          textAlign : "Left",  
	          design : "Bold" 
	            }) ], 
	     
	         contentRight : []  
	        }); 
			
			title: "Patient Registration"
			var oController = this.getController();
			var oMatrix = new sap.ui.commons.layout.MatrixLayout({
				id : 'matrix4_1',
				layoutFixed : true,
				width : '1000px',
				columns : 5,
				widths : ['150px', '250px', '200px', '200px', '200px'] });
	            oMatrix.addStyleClass( "SapUiSizeCompact");
     		oMatrix.addStyleClass ("matrix_layout_css");
	            
	            
		    	var oCell = new sap.ui.commons.layout.MatrixLayoutCell({
				colSpan: 5 });
			 var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Contact Data', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oLabel = new sap.ui.commons.Label({
				id : 'L-Name_1',
				text : 'Name' });
			var oTF = new sap.ui.commons.TextField({
				id : 'TF-Name_1',
				tooltip : 'Name',
				editable : false,
                 value : "{patientdetdata>/d/Name}",
				width : '350px' });
			oLabel.setLabelFor(oTF);
			
			var oLabel12 = new sap.ui.commons.Label({
				id : 'email_Name_1',
				text : 'Email ID' });
			var oTF12 = new sap.ui.commons.TextField({
				id : 'emaill_Name_1',
				tooltip : 'Email',
				editable : false,
				value : "{patientdetdata>/d/emailid}",
				width : '300px' });
			oLabel12.setLabelFor(oTF12);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({
				rowSpan : 7 });
			var oImg = new sap.ui.commons.Image({
				id : 'IMG-Pic_1',
				src :  "{patientdetdata>/d/PATIENTURI}",// 'codeblue/img/patient.png',
				alt : 'Face',
				tooltip : 'Picture of Contact',
				height : '150px' });
				oImg.addStyleClass ("Image_detail");
			oCell1.addContent(oImg);
			oMatrix.createRow(oLabel, oTF, oCell, oCell1);
			oMatrix.createRow(oLabel12, oTF12);
		    oLabel = new sap.ui.commons.Label({
				id : 'L-F-Name_1',
				text : 'Contact Number' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-F-Name_1',
				tooltip : 'First Name',
				editable : false,
			    value : "{patientdetdata>/d/Contact_Number}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);
	
			oLabel = new sap.ui.commons.Label({
				id : 'L-Street_1',
				text : 'Address' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-Address_1',
				tooltip : 'Address',
				editable :false,
			value : "{patientdetdata>/d/fullAddress}",
				width : '350px' });
			oLabel.setLabelFor(oTF);
			
	
	
			oMatrix.createRow(oLabel,oTF );
	
			oLabel = new sap.ui.commons.Label({
				id : 'L-City_1',
				text : 'Height' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-Height_1',
				tooltip : 'Height',
				editable :false,
				value : "{patientdetdata>/d/Hieght}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);
			
			
			oLabel = new sap.ui.commons.Label({
				id : 'Weight_1',
				text : 'Weight' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-Weight_1',
				tooltip : 'Weight',
				editable :false,
				value : "{patientdetdata>/d/Weight}",
				width : '300px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oTF);
	
	        
	        
	        
	        
	        
	        
	        oLabel = new sap.ui.commons.Label({
                                                id : 'L-Bloodgrp_1',
                                                text : 'Blood Group' });
                
                                oCB = new sap.ui.commons.ComboBox({
                                                id : 'TF-Bloodgrp_1',
                                                tooltip : 'Blood Group',
                                                editable : false,
                                                value : "{patientdetdata>/d/Blood_Group}",
                                                width : '200px' });
                                oLabel.setLabelFor(oCB);
                var oItem = new sap.ui.core.ListItem({
                                id : 'B11',
                                text : 'B-' });
                oCB.addItem(oItem);
                var oItem = new sap.ui.core.ListItem({
                                id : 'AB2',
                                text : 'AB+' });
                oCB.addItem(oItem);
                var oItem = new sap.ui.core.ListItem({
                                id : 'AB-',
                                text : 'AB-' });
                oCB.addItem(oItem);
                var oItem = new sap.ui.core.ListItem({
                                id : 'B12',
                                text : 'B+' });
                oCB.addItem(oItem);
                oMatrix.createRow(oLabel, oCB);

	        
	
			oLabel = new sap.ui.commons.Label({
				id : 'L-Date_1',
				text : 'Date of birth' });
				
				oDP = new sap.ui.commons.DatePicker({
	            id : 'DP-Date_1',
	            tooltip : 'Date of Birth',
	            editable : false,
	            yyyymmdd : "12/12/1970"//{patientdetdata>/d/DOB}"
	            });
			oLabel.setLabelFor(oDP);
			
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oLabel2 = new sap.ui.commons.Label({
				id : 'L-URL_1',
				text : 'URL for picture',
				visible : false });
			oMatrix.createRow(oLabel, oDP, oCell, oLabel2);
	
			oLabel = new sap.m.Label({
				id : 'L-Gender_1',
				text : 'Gender'
				});
			var oRBG = new sap.ui.commons.RadioButtonGroup({
				id : 'RBG-Gender_1',
				tooltip : 'Gender',
				columns : 2,
				selected : "{patientdetdata>/d/Gender}",
				editable : false });
			var oItem = new sap.ui.core.Item({
				id : 'RB-Male_1',
				text : 'Male',
				//tooltip : 'Gender: male',
				key : 'male' });
			oRBG.addItem(oItem);
			oItem = new sap.ui.core.Item({
				id : 'RB-Female_1',
				text : 'Female',
				tooltip : 'Gender: female',
				key : 'female' });
			oRBG.addItem(oItem);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
		    
			oTF = new sap.m.Input({
				id : 'TF-URL_1',
				tooltip : 'URL for picture',
				visible : false,
				value : 'images/face.png',
				width : '100%',
				change : function(oEvent){
					var oCore = sap.ui.getCore();
					var oTF = oEvent.oSource;
					var oIMG = oCore.getControl("IMG-Pic");
					oIMG.setSrc( oTF.getValue() );}
				});
			oLabel2.setLabelFor(oTF);
			oMatrix.createRow(oLabel, oRBG, oCell, oTF);
			
		
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
	
			var oRtt = new sap.ui.commons.RichTooltip(
					'Rtt-Change_1',
					{title: 'Change Button',
					text:"If you like to Change this data press this button. If not, don't press it."
					});
					
            var oButton1 = new sap.m.Button({
          id : 'B-Change_1',
          tooltip : oRtt,
          text : 'Change',
          icon : "sap-icon://edit",
          width : '10em',
          press : function(){
              var oCore = sap.ui.getCore();
              var oTF = oCore.getControl('TF-Name_1');
              oTF.setEditable(!oTF.getEditable());
              oTF = oCore.getControl('emaill_Name_1');
              oTF.setEditable(!oTF.getEditable());
              oTF = oCore.getControl('TF-F-Name_1');
              oTF.setEditable(!oTF.getEditable());
              oTF = oCore.getControl('TF-Address_1');
              oTF.setEditable(!oTF.getEditable());
              oTF = oCore.getControl('TF-Height_1');
              oTF.setEditable(!oTF.getEditable());
              var oCB = oCore.getControl('TF-Weight_1');
              oCB.setEditable(!oCB.getEditable());
              var oDP = oCore.getControl('TF-Bloodgrp_1');
              oDP.setEditable(!oDP.getEditable());
              var oRBG = oCore.getControl('DP-Date_1');
              oRBG.setEditable(!oRBG.getEditable());
              var oDP = oCore.getControl('RBG-Gender_1');
			    oDP.setEditable(!oDP.getEditable()); 
             
              oTP = oCore.getControl('TF-pulse_1');
               oTP.setEditable(!oTP.getEditable());
              oTF = oCore.getControl('TF-pulse1_1');
              oTF.setEditable(!oTF.getEditable());
              var oTA = oCore.getControl('tfoth_1');
              oTA.setEditable(!oTA.getEditable());
              var oCB = oCore.getControl('TF-bp_1');
              oCB.setEditable(!oCB.getEditable());
              var oDP = oCore.getControl('TF-bp1_1');
              oDP.setEditable(!oDP.getEditable());
              var oRBG = oCore.getControl('TF-tempar_1');
              oRBG.setEditable(!oRBG.getEditable());
               var oSelp = oCore.getControl('TF-sleep_1');
              oSelp.setEditable(!oSelp.getEditable());
              
              var oPgm = oCore.getControl('TF-prg1_1');
              oPgm.setEditable(!oPgm.getEditable());
              
               var oDoc = oCore.getControl('dc1_1');
              oDoc.setEditable(!oDoc.getEditable());
              
              
                var oEmer = oCore.getControl('TFe-Name_1');
              oEmer.setEditable(!oEmer.getEditable());
              
                var oEmer1 = oCore.getControl('TFe-Number_1');
              oEmer1.setEditable(!oEmer1.getEditable());
              
              
                var oEmer2 = oCore.getControl('TFe-NameEm_1');
              oEmer2.setEditable(!oEmer2.getEditable());
              
                var oEmcon = oCore.getControl('TFe-NumberE_1');
              oEmcon.setEditable(!oEmcon.getEditable());
                
                
                
              var oButton = oCore.getControl('B-Save_1');
              oButton  .setEnabled(!oButton.getEnabled());
              oButton = oCore.getControl('B-Change_1');
              var oRtt = oCore.getControl('Rtt-Change_1');
              if( oButton.getText() == 'Change'){
                   oButton.setText('Display');
                   oRtt.setText("If you not like to change these data press this button. If you still want to change, don't press it.");
              } else{
                   oButton.setText('Change');
                   oRtt.setText("If you like to change these data press this button. If not, don't press it.");
              }
          }

            });		
					
					
				oRtt = new sap.ui.commons.RichTooltip(
					'Rtt-Save_1',
					{title: 'Save Button',
					//imageSrc: '../images/save-icon.png',
					//imageSrc: 'images/save-icon.gif',
						width : '10em',
					text:"Press this button to save the value. But as long as we don't know where to save the data is not really saved."
					});
			var oButton2 = new sap.m.Button({
				id : 'B-Save_1',
				tooltip : oRtt,
				width : '10em',
				text : 'Save',
				icon : "sap-icon://save" ,
				//icon : '../images/save-icon.png',
				enabled: false,
			
				press : function(){alert("Values are saved into Valhall!")}
					
				}); 
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Medical Details', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			
		

        
			oLabel = new sap.ui.commons.Label({
				id : 'pulse_1',
				text : 'Pulse rate' });
	
			
		/*	oLabel1 = new sap.ui.commons.Label({
				id : 'pulse-_1',
				text : '_' });
	*/
			oTF = new sap.ui.commons.TextField({
				id : 'TF-pulse_1',
				tooltip : 'Pulse Rate',
				value : '103',
				editable : false,
				width : '90px' });
				
					/*oTF1 = new sap.ui.commons.TextField({
				id : 'TF-pulse1_1',
				tooltip : 'pulse',
				editable : false,
				value : '70',
				width : '90px' });*/
				
				oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
             oCell.addContent(oTF);
             oCell.addContent(oLabel1);
             oCell.addContent(oTF1)
			oMatrix.createRow(oLabel,oCell);


			oLabel = new sap.ui.commons.Label({
				id : 'bp_1',
				text : 'BP' });
	
			
		/*	oLabel1 = new sap.ui.commons.Label({
				id : 'BP-_1',
				text : '_' });*/
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-bp_1',
				tooltip : 'BP',
				editable : false,
				value : '103',
				width : '90px' });
				/*
					oTF1 = new sap.ui.commons.TextField({
				id : 'TF-bp1_1',
				tooltip : 'BP',
				editable : false,
				value : '123',
				width : '90px' });
				*/
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
             oCell.addContent(oTF);
             oCell.addContent(oLabel1);
             oCell.addContent(oTF1)
			oMatrix.createRow(oLabel,oCell);
			
		
		
		
// 	oMatrix.createRow(oLabel,oTF,oLabel2,oTf2);
			
			oLabel = new sap.ui.commons.Label({
				id : 'temprature_1',
				text : 'Temprture' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-tempar_1',
				tooltip : 'Temprture',
				editable : false,
				value : '108°',
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel,oTF);
			
		
			
			
			
			oLabel = new sap.ui.commons.Label({
				id : 'sleeping_hours_1',
				text : 'Sleeping hours' });
	
			oTF = new sap.ui.commons.TextField({
				id : 'TF-sleep_1',
				tooltip : 'Street',
				editable : false,
				value : "{patientdetdata>/d/SLEEPINGHOURS}" ,
				width : '150px' });
			oLabel.setLabelFor(oTF);
			oMatrix.createRow(oLabel,oTF);
						
			
			oLabel2 = new sap.ui.commons.Label({
				id : 'other_info_1',
				text : 'Other Information' });
	
			oTF2 = new sap.m.TextArea({
				id : 'tfoth_1',
				tooltip : 'Street',
				editable : false,
				value : "{patientdetdata>/d/Health_Condition}",
				width : '100%',
				height : '100px'});
			oLabel2.setLabelFor(oTF2);
			oMatrix.createRow(oLabel2,oTF2 );
			
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Program Details', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);

			
			//program details
			
			
				        oLabel = new sap.ui.commons.Label({
                                                id : 'prgram_1',
                                                text : 'Program Assigned' });
                
                                oCB = new sap.ui.commons.ComboBox({
                                                id : 'TF-prg1_1',
                                                tooltip : 'Programe',
                                                editable : false,
                                                value : "{patientdetdata>/d/Program_Name}",
                                                width : '200px' });
                                oLabel.setLabelFor(oCB);
                var oItem = new sap.ui.core.ListItem({
                                id : 'P11',
                                text : 'Post Nuero' });
                oCB.addItem(oItem);
                var oItem = new sap.ui.core.ListItem({
                                id : 'PB2',
                                text : 'Alzeimer Patient Monitoring' });
                oCB.addItem(oItem);
                
                //oMatrix.createRow(oLabel, oCB);
			
			
			
			oLabel1 = new sap.ui.commons.Label({
                                                id : 'doctor_1',
                                                text : 'Doctor Assigned' });
                
                                oCB1 = new sap.ui.commons.ComboBox({
                                                id : 'dc1_1',
                                                tooltip : 'Doctor',
                                                editable : false,
                                                value : "{patientdetdata>/d/Doctor_Name}",
                                                width : '200px' });
                                oLabel.setLabelFor(oCB1);
                var oItem = new sap.ui.core.ListItem({
                                id : 'D11',
                                text : 'Dr. Nuero' });
                oCB1.addItem(oItem);
                var oItem = new sap.ui.core.ListItem({
                                id : 'DB2',
                                text : ' Dr.Alzeimer' });
                oCB1.addItem(oItem);
                
              
			
			oMatrix.createRow(oLabel, oCB, oLabel1, oCB1);
			
			
			//program details
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
			oCell.addContent(new sap.ui.commons.TextView({text: 'Emergency Contact', design: sap.ui.commons.TextViewDesign.H2}));
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			
			var oLabel = new sap.ui.commons.Label({
				id : 'Le-Name_1',
				text : 'Name 1' });
			var oTF = new sap.ui.commons.TextField({
				id : 'TFe-Name_1',
				tooltip : 'Name 1',
				editable : false,
				value :  "{patientdetdata>/d/emergency_contact1_name}",
				width : '200px' });
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({rowSpan : 7 });
			var oLabel1 = new sap.ui.commons.Label({
				id : 'Le-Number_1',
				text : 'Contact number' });
			var oTF1 = new sap.ui.commons.TextField({
				id : 'TFe-Number_1',
				tooltip : 'Name 1',
				editable : false,
				value :'9808765879',//"{patientdetdata>/d/Emergency_Contact_1}",
				width : '200px' });
			oLabel1.setLabelFor(oTF1);
			oCell1.addContent(oLabel1);
			oMatrix.createRow(oLabel, oTF,oLabel1, oTF1 );
			
			
			var oLabel = new sap.ui.commons.Label({
				id : 'Le-EmerName_1',
				text : 'Name 2' });
			var oTF = new sap.ui.commons.TextField({
				id : 'TFe-NameEm_1',
				tooltip : 'Name 2',
				editable : false,
					value :  "{patientdetdata>/d/emergency_contact2_name}",
				width : '200px' });
			oLabel.setLabelFor(oTF);
			oCell = new sap.ui.commons.layout.MatrixLayoutCell();
			oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({rowSpan : 7 });
			var oLabel1 = new sap.ui.commons.Label({
				id : 'Le-EmerNumber_1',
				text : 'Contact number' });
			var oTF1 = new sap.ui.commons.TextField({
				id : 'TFe-NumberE_1',
				tooltip : 'Name',
				editable : false,
				value :'78739993333',//"{patientdetdata>/d/ Emergency_Contact_2}",
				width : '200px' });
			oLabel1.setLabelFor(oTF1);
			oCell1.addContent(oLabel1);
			oMatrix.createRow(oLabel, oTF,oLabel1, oTF1 );
			
			
			
			
			
			
			
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 8});
			oCell.addContent(new sap.ui.commons.HorizontalDivider());
			oMatrix.createRow(oCell);
			
			
		
	
			oMatrix.createRow(oButton1, oButton2);
	
			// attach it to some element in the page
			//oMatrix.placeAt('sample4');
		    var page = new sap.m.Page("RegPage1",{
		         press: function(){
		        	 sap.ui.getCore().byId("codeblueapp").to("idRegister1");
		             
		         },
		        content: [oMatrix]
		}); 
		    page.setCustomHeader(oBar);
		    page.addStyleClass("SapUiSizeCompact");
		    return page;
	
		 },
		 	renderdata:function(oModel){
// 		var list = sap.ui.getCore().byId("patientlist");
// 		var oModel = this.getModel("patientdata");
		   this.setModel(oModel);
		 	}
	
		});