sap.ui.jsview("codeblue.master", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf codeblue.master
	*/ 
	getControllerName : function() {
		return "codeblue.master";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf codeblue.master
	*/ 
	createContent : function(oController) {
 		var page= new sap.m.Page({
			title: "Patient Names"});
 		var serchfield = new sap.m.SearchField({
 			width : "100%"
 		});
 		var toolbar = new sap.m.Toolbar();
 		toolbar.addContent (serchfield);
 		page.setSubHeader(toolbar);
 		
 		
 		var list = new sap.m.List("patientlist");
			list.setBackgroundDesign("Transparent"); 
			
		
	  var listItem = new sap.m.StandardListItem({
	        title : "{Name}",
	        type:"Active",
	        press: function(){
	    var oModel = this.getModel("patientdata");
	    var current_patient = oModel.getProperty(this.getBindingContext().getPath());
		var path = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient";
		path = path +  "('" +  current_patient.Patient_Id + "')";
		path = path + "?$format=json";
	    // temp = new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Patient('ABC')?$format=json");
        var modeldetails = new sap.ui.model.json.JSONModel(path);
    	var detailview =sap.ui.getCore().byId("detail");
        detailview.setModel(modeldetails,"patientdetdata");
	        }
	    });
	  list.bindItems("/d/results",listItem);
		    page.addContent(list);
			return page;
	},
	
	
	renderdata:function(){
		var list = sap.ui.getCore().byId("patientlist");
		var oModel = this.getModel("patientdata");
		   list.setModel(oModel);
	}
	
   
});