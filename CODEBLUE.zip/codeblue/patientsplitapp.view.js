sap.ui.jsview("codeblue.patientsplitapp", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf codeblue.patientsplitapp
	*/ 
	getControllerName : function() {
		return "codeblue.patientsplitapp";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf codeblue.patientsplitapp
	*/ 
	createContent : function(oController) {
		var ologo = new sap.m.Image({  
	          src : "img/cblue.jpg"     
	            });
	            
	            
	            var saplogo =new sap.m.Image({  
	          src : "img/SAP.jpg"     
	            });
	            ologo.addStyleClass("codebluelogo");
		 var oBar = new sap.m.Bar( {  
		        design:sap.m.BarDesign.Header,
		        //design: sap.m.BarDesign.SubHeader,
	          contentLeft : [saplogo],  
	         
	          contentMiddle : [ ologo ], 
	     
	         contentRight : [new sap.m.Button({
					icon: "sap-icon://nav-back",
					press: function(){
						sap.ui.getCore().byId("codeblueapp1").to("idEntry1");
					}
				})]  
	        }); 
	        

		var page = new sap.m.Page ( {});
		page.setCustomHeader(oBar);
		var app = new sap.m.SplitApp("splitApp",{mode : sap.m.SplitAppMode.ShowHideMode});
		var master = sap.ui.view({id:"master", viewName:"codeblue.master", type:sap.ui.core.mvc.ViewType.JS});
		app.addMasterPage(master);
				
		var detail = sap.ui.view({id:"detail", viewName:"codeblue.detail", type:sap.ui.core.mvc.ViewType.JS});
		app.addDetailPage(detail);
		
		page.addContent (app);
		return page;
		
		
	}
	
	
     
});