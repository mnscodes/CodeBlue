    sap.ui.jsview("codeblue.detail", {
    
    	/** Specifies the Controller belonging to this View. 
    	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
    	* @memberOf codeblue.detail
    	*/ 
    	getControllerName : function() {
    		return "codeblue.detail";
    	},
    
    	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
    	* Since the Controller is given to this method, its event handlers can be attached right away. 
    	* @memberOf codeblue.detail
    	*/ 
    	createContent : function(oController) {
     		var page = new sap.m.Page({
    			title: "Patient Details"
    		});
    		
    		
    
     	
     		
     		page.addStyleClass( "SapUiSizeCompact");
     		
     		
     		
     		 var oMatrix = new sap.ui.commons.layout.MatrixLayout({
                //  id : 'Pmatrix41',
                 layoutFixed : true,
                 width : '1000px',
                 columns : 5,
                 widths : ['100px', '250px', '200px', '200px', '200px'] });
     		oMatrix.addStyleClass( "SapUiSizeCompact");
     		oMatrix.addStyleClass ("matrix_layout_css");
             
             var oCell = new sap.ui.commons.layout.MatrixLayoutCell({
                 colSpan: 5 });
    
    // var oTV = new sap.ui.commons.TextView({
    //              id : 'PTV-Head',
    //              text : 'Contact Data',
    //              design : sap.ui.commons.TextViewDesign.H2 });
    
    //oCell.addContent(oTV);
    //oMatrix.createRow(oCell);
    var oTVemp = new sap.ui.commons.TextView({
                 id : 'PTV-Head11'
                 });
    oCell.addContent(oTVemp)
    oMatrix.createRow(oCell);
    var oLabel = new sap.m.Label({
                 id : 'PL-Name',
                 text : 'Name' });
    
    var oTF = new sap.m.Input({
                 id : 'PTF-Name',
                 tooltip : 'Name',
                 editable : false,
                 value : "{patientdetdata>/d/Name}",
                 width : '200px' });
    
    oLabel.setLabelFor(oTF);
    
    oCell = new sap.ui.commons.layout.MatrixLayoutCell();
    oCell1 = new sap.ui.commons.layout.MatrixLayoutCell({
                 rowSpan : 7 });
    var oImg = new sap.ui.commons.Image({
                 id : 'PIMG-Pic',
                 src : 'codeblue/img/patient.png',
                 alt : 'Face',
                 tooltip : 'Picture of Contact',
                 height : '200px' });
    oCell1.addContent(oImg);
    oMatrix.createRow(oLabel, oTF, oCell, oCell1);
    
    oLabel = new sap.m.Label({
                 id : 'PL-F-Name',
                 text : 'Email ID' });
    
    oTF = new sap.m.Input({
                 id : 'PTF-F-Name',
                 tooltip : 'Email id',
                 editable : false,
                 value : 'Max',
                 width : '200px' });
    oLabel.setLabelFor(oTF);
    oMatrix.createRow(oLabel, oTF);
    
   
    oLabel1 = new sap.m.Label({
        id : 'PL-Street',
        text : 'Age' });
    
    
    oTF = new sap.m.Input({
                 id : 'PTF-Street',
                 tooltip : 'Age',
                 editable : false,
                 value : '{patientdetdata>/Age}',
                 width : '150px' });
    oLabel.setLabelFor(oTF);
    
     oLabel = new sap.m.Label({
                 id : 'PL-housenum',
                 text : 'Contact Number' });
    
    var oTF2 = new sap.m.Input({
                 id : 'PTF-HNum',
                 tooltip : 'Contact Number',
                 editable : false,
                 value : '{patientdetdata>/Contact_Number}',
                 width : '50px',
                 maxLength : 10 });
    oMatrix.createRow(oLabel1, oTF);
    //multiple controls within one cell
    //oCell = new sap.ui.commons.layout.MatrixLayoutCell();
    //oCell.addContent(oTF);
    //oCell.addContent(oTF2);
    oMatrix.createRow(oLabel, oTF2);
    
    oLabel = new sap.m.Label({
                 id : 'PL-City',
                 text : 'Address' });
    
    oTF = new sap.m.TextArea({
                 id : 'PTF-City',
                 tooltip : 'Address',
                 editable : false,
                 value : '{patientdetdata>/Address}',
                 width : '200px' });
    oLabel.setLabelFor(oTF);
    oMatrix.createRow(oLabel, oTF);
    
    oLabel = new sap.m.Label({
                 id : 'PL-Country',
                 text : 'Emaergency Contact' });
    
    
    var oCBnum = new sap.m.Input({
                 id : 'PTF-EmerNum',
                 tooltip : 'Contact Number',
                 editable : false,
                 value : '{patientdetdata>/Contact_Number}',
                 width : '50px',
                 maxLength : 10 });
    oCB = new sap.m.Select({
                 id : 'PTF-Country',
                 tooltip : 'Country',
                 enabled : false,
                 value : '{patientdetdata>/Address}',
                 width : '200px' });
    oLabel.setLabelFor(oCB);
    var oItem = new sap.ui.core.ListItem({
                 id : 'PLI1',
                 text : 'Canada' });
    oCB.addItem(oItem);
    var oItem = new sap.ui.core.ListItem({
                 id : 'PLI2',
                 text : 'Deutschland' });
    oCB.addItem(oItem);
    var oItem = new sap.ui.core.ListItem({
                 id : 'PLI3',
                 text : 'England' });
    oCB.addItem(oItem);
    var oItem = new sap.ui.core.ListItem({
                 id : 'PLI4',
                 text : '??????' });
    oCB.addItem(oItem);
    oMatrix.createRow(oLabel, oCBnum);
    
    oLabel = new sap.m.Label({
                 id : 'PL-Date',
                 text : 'Date of birth' });
    oDP = new sap.m.DatePicker({
                 id : 'PDP-Date',
                 tooltip : 'Date of Birth',
                 editable : false,
                 yyyymmdd : 19990909 });
    oLabel.setLabelFor(oDP);
    oCell = new sap.ui.commons.layout.MatrixLayoutCell();
    oLabel2 = new sap.ui.commons.Label({
                 id : 'PL-URL',
                 text : 'URL for picture',
                 visible : false });
    oMatrix.createRow(oLabel, oDP, oCell, oLabel2);
    
    oLabel = new sap.m.Label({
                 id : 'PL-Gender',
                 text : 'Gender' });
    var oRBG = new sap.ui.commons.RadioButtonGroup({
                 id : 'PRBG-Gender',
                 tooltip : 'Gender',
                 columns : 2,
                 editable : false });
    var oItem = new sap.ui.core.Item({
                 id : 'PRB-Male',
                 text : 'Male',
                 tooltip : 'Gender: male',
                 key : 'male' });
    oRBG.addItem(oItem);
    oItem = new sap.ui.core.Item({
                 id : 'PRB-Female',
                 text : 'Female',
                 tooltip : 'Gender: female',
                 key : 'female' });
    oRBG.addItem(oItem);
    oCell = new sap.ui.commons.layout.MatrixLayoutCell();
    
    oTF = new sap.m.Input({
                 id : 'PTF-URL',
                 tooltip : 'URL for picture',
                 visible : false,
                 value : 'images/face.png',
                 width : '100%',
                 change : function(oEvent){
                                 var oCore = sap.ui.getCore();
                                 var oTF = oEvent.oSource;
                                 var oIMG = oCore.getControl("IMG-Pic");
                                 oIMG.setSrc( oTF.getValue() );}
                 });
    oLabel2.setLabelFor(oTF);
    oMatrix.createRow(oLabel, oRBG, oCell, oTF); 
    
    oLabel = new sap.m.Label({
                 id : 'PL-Text',
                 text : 'Remarks' });
    oCell = new sap.ui.commons.layout.MatrixLayoutCell({
                 colSpan : 4 });
    oTA = new sap.m.TextArea({
                 id : 'PTA-Text',
                 tooltip : 'Remarks',
                 editable : false,
                 wrapping : sap.ui.core.Wrapping.Off,
                 value : 'Max Mustermann is a very nice guy. He is very well known.\nEverybody loves him.\nYou can be lucky if you meet him.',
                 width : '80%',
                 height : '150px'
                 });
    oLabel.setLabelFor(oTA);
    oCell.addContent(oTA);
    oMatrix.createRow(oLabel, oCell);
    
    var oRtt = new sap.ui.commons.RichTooltip(
                                 'PRtt-Change',
                                 {title: 'Change Button',
                                 text:"If you like to change this data press this button. If not, don't press it."
                                 });
    var oButton1 = new sap.m.Button({
                 id : 'PB-Change',
                 tooltip : oRtt,
                 text : 'Change',
                 icon : "sap-icon://edit",
                 width : '10em',
                 press : function(){
                                 var oCore = sap.ui.getCore();
                                 var oTF = oCore.getControl('PTF-Name');
                                 oTF.setEditable(!oTF.getEditable());
                                 oTF = oCore.getControl('PTF-F-Name');
                                 oTF.setEditable(!oTF.getEditable());
                                 oTF = oCore.getControl('PTF-Street');
                                 oTF.setEditable(!oTF.getEditable());
                                 oTF = oCore.getControl('PTF-HNum');
                                 oTF.setEditable(!oTF.getEditable());
                                 oTF = oCore.getControl('PTF-City');
                                 oTF.setEditable(!oTF.getEditable());
                                 var oCB = oCore.getControl('PTF-Country');
                                 oCB.setEnabled(!oCB.getEnabled());
                                 var oDP = oCore.getControl('PDP-Date');
                                 oDP.setEditable(!oDP.getEditable());
                                 var oRBG = oCore.getControl('PRBG-Gender');
                                 oRBG.setEditable(!oRBG.getEditable());
                                 var oLabel = oCore.getControl('PL-URL');
                                 oLabel.setVisible(!oLabel.getVisible());
                                 oTF = oCore.getControl('PTF-URL');
                                 oTF.setVisible(!oTF.getVisible());
                                 var oTA = oCore.getControl('PTA-Text');
                                 oTA.setEditable(!oTA.getEditable());
                                 var oButton = oCore.getControl('PB-Save');
                                 oButton.setEnabled(!oButton.getEnabled());
                                 oButton = oCore.getControl('PB-Change');
                                 var oRtt = oCore.getControl('PRtt-Change');
                                 if( oButton.getText() == 'Change'){
                                                 oButton.setText('Display');
                                                 oRtt.setText("If you not like to change these data press this button. If you still want to change, don't press it.");
                                 } else{
                                                 oButton.setText('Change');
                                                 oRtt.setText("If you like to change these data press this button. If not, don't press it.");
                                 }
                 }
                 });
    oRtt = new sap.ui.commons.RichTooltip(
                                 'PRtt-Save',
                                 {title: 'Save Button',
                                 /*imageSrc: '../images/save-icon.png',
                                 imageSrc: 'images/save-icon.gif',*/
                                 text:"Press this button to save the value. But as long as we don't know where to save the data is not really saved."
                                 });
    var oButton2 = new sap.m.Button({
                 id : 'PB-Save',
                 tooltip : oRtt,
                 text : 'Save',
                 icon : "sap-icon://save" ,
                 enabled: false,
                 press : function(){
                     var data_model = this.getModel("patientdetdata");
                     alert(JSON.stringify(data_model.getData()));
                 }
                 });
    
    oMatrix.createRow(oButton1, oButton2);
               /* page.addContent (oSimpleForm1);
     			page.addContent (oSimpleForm2);
     			page.addContent (oSimpleForm3);
     	    	page.addContent (oSimpleForm4);*/
     		
     		
     		page.addContent(oMatrix);
     		
     		
     		
     		return page;
    	},


	renderdata:function(oModel){
// 		var list = sap.ui.getCore().byId("patientlist");
// 		var oModel = this.getModel("patientdata");
		   this.setModel(oModel);
	}
    
    });