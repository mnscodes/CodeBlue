/*sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status :  function (sStatus) {
				if (sStatus === "No Emergency") {
					return "Success";
				} else if (sStatus === "Emergency"){
					return "Error";
				} else {
					return "None";
				}
		}
	};

	return Formatter;

},  bExport=  true);
*/

jQuery.sap.declare("idoctor.Formatter");
idoctor.Formatter = {
		
		status :  function (sStatus) {
			if (sStatus === "No Emergency") {
				return "Success";
			} else if (sStatus === "Emergency"){
				return "Error";
			} else {
				return "None";
			}
	}	
};