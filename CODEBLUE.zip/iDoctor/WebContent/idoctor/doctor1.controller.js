sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'./Formatter',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		'sap/viz/ui5/controls/common/feeds/FeedItem',
		'sap/viz/ui5/data/FlattenedDataset',
        'sap/viz/ui5/format/ChartFormatter',
        'sap/m/Popover',
        './ControllerOverall'
	], function(jQuery, MessageToast, Formatter, Controller, JSONModel, FeedItem, FlattenedDataset, ChartFormatter, Popover, ControllerOverAll ) {
	"use strict";

	var cController = Controller.extend("idoctor.doctor1", {

		onInit: function () {
			// set explored app's demo model on this sample
			var dataPath = "./idoctor/dataset";
		var oModel2 = new JSONModel(dataPath + "Patient.json");
		var oModelTable = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/RuleSos?$format=json");
			
		        var table1 = this.getView().byId("activeTable");
			    table1.setModel(oModelTable);
			    oModelTable.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
 var oModelRange = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs");
			
				
				if(oModelRange)
		        {
			           this.getView().setModel(oModelRange,"rangedata");
		        }
		        var oV = this.getView().byId("vid");
			    oV.setModel(oModelRange);
			    oModelRange.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			
			var oModel = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/severity.xsjs");
					
			this.byId("master").setModel(oModel);
		//	this.byId("oh1").setModel(oModel);
			
			SVGElement.prototype.getTransformToElement = SVGElement.prototype.getTransformToElement || function(elem) { return elem.getScreenCTM().inverse().multiply(this.getScreenCTM()); }; 
			var oVizFrame = this.getView().byId("idVizFrameLine");
			  //var oFixFlex = this.getView().byId("idFixFlex");
          //  ControllerOverall.customFormat(); // set customized format
          //  ControllerOverall.loadLibrary(oVizFrame); // load "sap.suite.ui.commons"
            
            //var oVizFrame = this.getView().byId("idVizFrameLine");
            oVizFrame.setVizType('line');
            oVizFrame.setUiConfig({
                "applicationSet": "fiori"
            });
            // Use UI5 formatter
            var FIORI_LABEL_SHORTFORMAT_10 = "__UI5__ShortIntegerMaxFraction10";
            var FIORI_LABEL_FORMAT_2 = "__UI5__FloatMaxFraction2";
            var FIORI_LABEL_SHORTFORMAT_2 = "__UI5__ShortIntegerMaxFraction2";
            var chartFormatter = ChartFormatter.getInstance();
            chartFormatter.registerCustomFormatter(FIORI_LABEL_SHORTFORMAT_10, function(value) {
                var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({style: "short",
                    maxFractionDigits: 10});
                return fixedInteger.format(value);
            });
            chartFormatter.registerCustomFormatter(FIORI_LABEL_FORMAT_2, function(value) {
                var fixedFloat = sap.ui.core.format.NumberFormat.getFloatInstance({style: 'Standard',
                    maxFractionDigits: 2});
                return fixedFloat.format(value);
            });
            chartFormatter.registerCustomFormatter(FIORI_LABEL_SHORTFORMAT_2, function(value) {
                var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({style: "short",
                    maxFractionDigits: 2});
                return fixedInteger.format(value);
            });
            sap.viz.api.env.Format.numericFormatter(chartFormatter);
            
            var oPopOver = this.getView().byId("idPopOver");
            oPopOver.connect(oVizFrame.getVizUid());
            oPopOver.setFormatString(FIORI_LABEL_FORMAT_2);
		
            var oModel1 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/chart.xsjs?$format=json");
            var oModelS = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/chart.xsjs?$format=json");
            var oModelL = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/chart.xsjs?$format=json");
           
            var oDataset = new FlattenedDataset({
                dimensions: [{
                    name: 'Timestamp',
                    value: "{Timestamp}"
                }],
                measures: [{
                
                    name: 'Heart_Beat',
                    value: '{Heart_Beat}'
                },
                {
                
                    name: 'Temperature',
                    value: '{Temperature}'
                }],
                
                data: {
                    path: "/value"
                }
            });
            oVizFrame.setDataset(oDataset);
            oVizFrame.setModel(oModel1);

            oVizFrame.setVizProperties({
                general: {
                    layout: {
                        padding: 0.04
                    }
                },
                valueAxis: {
                    label: {
                        formatString:FIORI_LABEL_SHORTFORMAT_10
                    },
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    }
                },
                plotArea: {
                    dataLabel: {
                        visible: true,
                        formatString:FIORI_LABEL_SHORTFORMAT_2
                    }
                },
                legend: {
                    title: {
                        visible: false
                    }
                },
                title: {
                    visible: false
                }
            });        

            var feedValueAxis = new FeedItem({
                    'uid': "valueAxis",
                    'type': "Measure",
                    'values': ["Heart_Beat", "Temperature"]
                }),
                feedCategoryAxis = new FeedItem({
                    'uid': "categoryAxis",
                    'type': "Dimension",
                    'values': ["Timestamp"]
                });
            oVizFrame.addFeed(feedValueAxis);
            oVizFrame.addFeed(feedCategoryAxis);
              var feedValueAxis2 = new FeedItem({
                    'uid': "valueAxis2",
                    'type': "Measure",
                    'values': ["Temperature"]
                }),  feedCategoryAxis2 = new FeedItem({
                    'uid': "categoryAxis2",
                    'type': "Dimension",
                    'values': ["Timestamp"]
                });
               oVizFrame.addFeed(feedValueAxis2);  
            oVizFrame.addFeed(feedCategoryAxis2);
//try for autorefresh
oVizFrame.addEventDelegate({
     "onAfterRendering": function () {
          // Your code ...
          setInterval(function() {
         oModel1 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/chart.xsjs?$format=json");
         oVizFrame.setModel(oModel1);
    }, 25000); 
     }
}, this);

            var oPanel1 = this.getView().byId("PN-1");
            var oContainer = this.getView().byId("idContainer");
            var oRadio1 = this.getView().byId("RB1-11");
            var oRadio2 = this.getView().byId("RB1-22");
            var oRadio3 = this.getView().byId("RB1-33");
            var oRadio4 = this.getView().byId("RB2-1");
            var oRadio5 = this.getView().byId("RB2-2");
            var oSwitch1 = this.getView().byId("SW-1");
            var oSwitch2 = this.getView().byId("SW-2");
            var oBox1 = this.getView().byId("BX-1");
            var oBox2 = this.getView().byId("BX-2");
            var oBox3 = this.getView().byId("BX-3");
            var oHBox = this.getView().byId("HB-1");

            
         //   ControllerOverall.adjustStyle(oRadio1,oRadio2,oRadio3,oRadio4,oRadio5,
              //      null,null,null,null,null,oBox1,oBox2,oBox3,null,null,oHBox); 
            // adjust style class to RTL mode
//            ControllerOverall.setExpanding(oPanel1); // set automatic expanding of setting panel

            // buttons control
            oRadio1.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModelS);
                }
            });
            oRadio2.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModel1);
                }
            });
            oRadio3.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModelL);
                }
            });
            oRadio4.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.removeFeed(feedValueAxis);
                    feedValueAxis = new FeedItem({
                        'uid': "valueAxis",
                        'type': "Measure",
                        'values': ["Heart_Beat"]
                    });
                    oVizFrame.addFeed(feedValueAxis);
                }
            });
            oRadio5.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.removeFeed(feedValueAxis);
                    feedValueAxis = new FeedItem({
                        'uid': "valueAxis",
                        'type': "Measure",
                        'values': ["Heart_Beat", 165]
                    });
                    oVizFrame.addFeed(feedValueAxis);
                }
            });
            oSwitch1.attachChange(function() {
                if(this.getState()) {
                    oVizFrame.setVizProperties({
                        plotArea: {
                            dataLabel: {
                                visible: true
                            }
                        }
                    });
                }
                if(!this.getState()) {
                    oVizFrame.setVizProperties({
                        plotArea: {
                            dataLabel: {
                                visible: false
                            }
                        }
                    });
                }
            });
            oSwitch2.attachChange(function() {
                if(this.getState()) {
                    oVizFrame.setVizProperties({
                        valueAxis: {
                            title: {
                                visible: true
                            }
                        },
                        categoryAxis: {
                            title: {
                                visible: true
                            }
                        }
                    });
                }
                if(!this.getState()) {
                    oVizFrame.setVizProperties({
                        valueAxis: {
                            title: {
                                visible: false
                            }
                        },
                        categoryAxis: {
                            title: {
                                visible: false
                            }
                        }
                    });
                }
            });
			
			
			
		},
		
	
 
		onOrientationChange: function(oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {duration: 5000});
		},
 
		handleRealTimePress : function(oEvent) {
		    var oModelTable = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/RuleSos?$format=json&$filter=Patient_Id eq 'ABC6'");
			
		        var table1 = this.getView().byId("activeTable");
			    table1.setModel(oModelTable);
			    oModelTable.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},
 
		onPressDetailBack : function() {
			this.getSplitAppObj().backDetail();
		},
 
		onPressMasterBack : function() {
			this.getSplitAppObj().backMaster();
		},
 
		onPressGoToMaster : function() {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},
 
		onListItemPress : function(oEvent) {
		//	var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
           var obj = oEvent.getSource().getBindingContext().getObject();
			this.getSplitAppObj().toDetail(this.createId("detail"), obj);
			var oModel = new JSONModel(obj);
			//oHeader.setModel(oModel, "model");
			var temp=oEvent.getSource().getBindingContext().getObject().Patient_Id;
            this.getView().byId("id1").setText(temp);
            var temp2 = oEvent.getSource().getBindingContext().getObject().Patient_Name;
			this.getView().byId("oh1").setTitle(temp2);
			 var temp3 = oEvent.getSource().getBindingContext().getObject().Program_Name;
			this.getView().byId("id2").setText(temp3);
			var temp4 = oEvent.getSource().getBindingContext().getObject().Severity;
			this.getView().byId("id3").setText(temp4);
			
			
		},
 
		onPressModeBtn : function(oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();
 
			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {duration: 5000});
		},
 
		getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		},
 
	
 
		
		
	onChange: function(oEvent){
		    
		    var oItem = oEvent.getSource();
		    //arr.push(oItem._aInitialFocusRange); 
		 if(oItem.sId === "iddoctor11--range-iddoctor11--vid-0"){
          var sUrl = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs?min="+oItem._aInitialFocusRange[0]+"&max="+oItem._aInitialFocusRange[1]+"&param=2";
           }  
           else if(oItem.sId === "iddoctor11--range-iddoctor11--vid-1") {
               var sUrl = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs?min="+oItem._aInitialFocusRange[0]+"&max="+oItem._aInitialFocusRange[1]+"&param=1";
           }
            var oRange = {};
         
         oRange.range = [ oItem._aInitialFocusRange[0], oItem._aInitialFocusRange[1]] ;
         
           /* oRange = arr;*/
            $.ajax({
                  type : "POST",
                  url : sUrl,
                 // data : JSON.stringify(oRange.innerHTML),
                  accept: "application/json",
                  //contentType = "application/json",
                  success : function(data, statusText, jqXHR) {
                        sap.m.MessageToast.show("Parameters Modified", data);
                        //sap.ui.getCore().byId("idEditMyProfile").getParent().to("idMyProfile1");
                  },
                  error : function(oError) {
                        jQuery.sap.log.error("Parameters cannot be modified!");
                  }
            });
			
		},
		newfn :  function (sStatus) {
			if (sStatus === "No Emergency") {
				return "Success";
			} else if (sStatus === "Emergency"){
				return "Error";
			} else {
				return "None";
			}
	}	
	});
	
	
	
	
	
	
	
return cController;




});