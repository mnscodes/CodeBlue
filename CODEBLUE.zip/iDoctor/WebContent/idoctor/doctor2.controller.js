/*sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("program.controller.View1", {

	});

});*/
sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter',
		'sap/ui/model/json/JSONModel',
		'sap/viz/ui5/controls/common/feeds/FeedItem',
        'sap/viz/ui5/data/FlattenedDataset',
        'sap/viz/ui5/format/ChartFormatter',
        'sap/m/Popover',
        './ControllerOverall'
	], function(jQuery, MessageToast, Fragment, Controller, Filter, JSONModel, FeedItem, FlattenedDataset, ChartFormatter, Popover, ControllerOverall) {
	"use strict";
    var arr = new Array(); 

	var CController = Controller.extend("program.program", {

		onInit: function(){
			
		
		    var dataPath = "program/dataset";
	        var oModelRange = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs");
		
			if(oModelRange)
	        {
		           this.getView().setModel(oModelRange,"rangedata");
	        }
	        var oV = this.getView().byId("vid");
		    oV.setModel(oModelRange);
		    oModelRange.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

		    var oProgram = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Program?$format=json");
		    if(oProgram){
		    var odetail = this.getView().byId("d");
		        odetail.setModel(oProgram);
		    }
			
			SVGElement.prototype.getTransformToElement = SVGElement.prototype.getTransformToElement || function(elem) { return elem.getScreenCTM().inverse().multiply(this.getScreenCTM()); }; 
			var oVizFrame = this.getView().byId("idVizFrameLine");
		//	var oListItem = this.getView().byId("parameterList");
			var oDoctorList = this.getView().byId("doctorsList");
		
			//var oModelP = new JSONModel(dataPath + "/param.json");
			var oModelD = new JSONModel(dataPath + "/doctors.json");
			oDoctorList.setModel(oModelD);
			//oListItem.setModel(oModelP);
			

			 
            //var oFixFlex = this.getView().byId("idFixFlex");
            ControllerOverall.customFormat(); // set customized format
            ControllerOverall.loadLibrary(oVizFrame); // load "sap.suite.ui.commons"
            
            //var oVizFrame = this.getView().byId("idVizFrameLine");
            oVizFrame.setVizType('line');
            oVizFrame.setUiConfig({
                "applicationSet": "fiori"
            });
            // Use UI5 formatter
            var FIORI_LABEL_SHORTFORMAT_10 = "__UI5__ShortIntegerMaxFraction10";
            var FIORI_LABEL_FORMAT_2 = "__UI5__FloatMaxFraction2";
            var FIORI_LABEL_SHORTFORMAT_2 = "__UI5__ShortIntegerMaxFraction2";
            var chartFormatter = ChartFormatter.getInstance();
            chartFormatter.registerCustomFormatter(FIORI_LABEL_SHORTFORMAT_10, function(value) {
                var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({style: "short",
                    maxFractionDigits: 10});
                return fixedInteger.format(value);
            });
            chartFormatter.registerCustomFormatter(FIORI_LABEL_FORMAT_2, function(value) {
                var fixedFloat = sap.ui.core.format.NumberFormat.getFloatInstance({style: 'Standard',
                    maxFractionDigits: 2});
                return fixedFloat.format(value);
            });
            chartFormatter.registerCustomFormatter(FIORI_LABEL_SHORTFORMAT_2, function(value) {
                var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({style: "short",
                    maxFractionDigits: 2});
                return fixedInteger.format(value);
            });
            sap.viz.api.env.Format.numericFormatter(chartFormatter);
            
            var oPopOver = this.getView().byId("idPopOver");
            oPopOver.connect(oVizFrame.getVizUid());
            oPopOver.setFormatString(FIORI_LABEL_FORMAT_2);
		
            var oModel = new JSONModel(dataPath + "/medium1.json");
            var oModelS = new JSONModel(dataPath + "/small1.json");
            var oModelL = new JSONModel(dataPath + "/Large1.json");
           
            var oDataset = new FlattenedDataset({
                dimensions: [{
                    name: 'time',
                    value: "{time}"
                }],
                measures: [{
                    name: 'value',
                    value: '{value}'
                }, {
                    name: 'cardiacrange',
                    value: '{cardiacrange}'
                }],
                
                data: {
                    path: "/program"
                }
            });
            oVizFrame.setDataset(oDataset);
            oVizFrame.setModel(oModel);

            oVizFrame.setVizProperties({
                general: {
                    layout: {
                        padding: 0.04
                    }
                },
                valueAxis: {
                    label: {
                        formatString:FIORI_LABEL_SHORTFORMAT_10
                    },
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    }
                },
                plotArea: {
                    dataLabel: {
                        visible: true,
                        formatString:FIORI_LABEL_SHORTFORMAT_2
                    }
                },
                legend: {
                    title: {
                        visible: false
                    }
                },
                title: {
                    visible: false
                }
            });        

            var feedValueAxis = new FeedItem({
                    'uid': "valueAxis",
                    'type': "Measure",
                    'values': ["value"]
                }),
                feedCategoryAxis = new FeedItem({
                    'uid': "categoryAxis",
                    'type': "Dimension",
                    'values': ["time"]
                });
            oVizFrame.addFeed(feedValueAxis);
            oVizFrame.addFeed(feedCategoryAxis);

            var oPanel1 = this.getView().byId("PN-1");
            var oContainer = this.getView().byId("idContainer");
            var oRadio1 = this.getView().byId("RB1-11");
            var oRadio2 = this.getView().byId("RB1-22");
            var oRadio3 = this.getView().byId("RB1-33");
            var oRadio4 = this.getView().byId("RB2-1");
            var oRadio5 = this.getView().byId("RB2-2");
            var oSwitch1 = this.getView().byId("SW-1");
            var oSwitch2 = this.getView().byId("SW-2");
            var oBox1 = this.getView().byId("BX-1");
            var oBox2 = this.getView().byId("BX-2");
            var oBox3 = this.getView().byId("BX-3");
            var oHBox = this.getView().byId("HB-1");

            
            ControllerOverall.adjustStyle(oRadio1,oRadio2,oRadio3,oRadio4,oRadio5,
                    null,null,null,null,null,oBox1,oBox2,oBox3,null,null,oHBox); 
            // adjust style class to RTL mode
//            ControllerOverall.setExpanding(oPanel1); // set automatic expanding of setting panel

            // buttons control
            oRadio1.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModelS);
                }
            });
            oRadio2.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModel);
                }
            });
            oRadio3.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.setModel(oModelL);
                }
            });
            oRadio4.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.removeFeed(feedValueAxis);
                    feedValueAxis = new FeedItem({
                        'uid': "valueAxis",
                        'type': "Measure",
                        'values': ["value"]
                    });
                    oVizFrame.addFeed(feedValueAxis);
                }
            });
            oRadio5.attachSelect(function(oEvent) {
                if(oEvent.getParameters().selected) {
                    oVizFrame.removeFeed(feedValueAxis);
                    feedValueAxis = new FeedItem({
                        'uid': "valueAxis",
                        'type': "Measure",
                        'values': ["value", "cardiacrange"]
                    });
                    oVizFrame.addFeed(feedValueAxis);
                }
            });
            oSwitch1.attachChange(function() {
                if(this.getState()) {
                    oVizFrame.setVizProperties({
                        plotArea: {
                            dataLabel: {
                                visible: true
                            }
                        }
                    });
                }
                if(!this.getState()) {
                    oVizFrame.setVizProperties({
                        plotArea: {
                            dataLabel: {
                                visible: false
                            }
                        }
                    });
                }
            });
            oSwitch2.attachChange(function() {
                if(this.getState()) {
                    oVizFrame.setVizProperties({
                        valueAxis: {
                            title: {
                                visible: true
                            }
                        },
                        categoryAxis: {
                            title: {
                                visible: true
                            }
                        }
                    });
                }
                if(!this.getState()) {
                    oVizFrame.setVizProperties({
                        valueAxis: {
                            title: {
                                visible: false
                            }
                        },
                        categoryAxis: {
                            title: {
                                visible: false
                            }
                        }
                    });
                }
            });
        },
   
	/*});*/
        
	
		onOrientationChange: function(oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {duration: 5000});
		},

		onPressNavToDetail : function(oEvent) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack : function() {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack : function() {
			this.getSplitAppObj().backMaster();
			this.getSplitAppObj().backDetail();
		},

		onPressGoToMaster : function() {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},
		
		onPressProgram : function(oEvent) {
				this.getSplitAppObj().toDetail(this.createId("detail2"));
		},

		onListItemPress : function(oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn : function(oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {duration: 5000});
		},

		getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		},
		
		handleRealTimePress : function() {
			this.getView().getParent().to("idOverAllAnalysis1");
		},
		
		onChangeEditMode: function(oEvent) {
			var oView = this.getView();
			var bFlag = !oView.byId("idCategory").getEditable();

			oView.byId("idProductId").setEditable(bFlag);
			oView.byId("idName").setEditable(bFlag);
			oView.byId("idCategory").setEditable(bFlag);
			
		},

		onChangeEnabledMode: function(oEvent) {
			var oView = this.getView();
			var bFlag = !oView.byId("idCategory").getEnabled();

			oView.byId("idProductId").setEnabled(bFlag);
			oView.byId("idName").setEnabled(bFlag);
			oView.byId("idCategory").setEnabled(bFlag);
			
		},
		
		handleIconTabBarSelect : function(oEvent) {
			var sKey = oEvent.getParameter("key");
			if(sKey === "editParameter" ) {
				this.byId("btnAdd").setEnabled(true);
			}
			if(sKey === "editDoctor") {
				this.byId("btnAdd").setEnabled(true);
			}
			if(sKey === "editAnalysis") {
				this.byId("btnAdd").setEnabled(false);
			}
			if(sKey === "editAbout") {
				this.byId("btnAdd").setEnabled(false);
			}
			
				
		},
		
		onBtnHome : function(){
			this.getView().getParent().to("idTile1");
		},
		
		/*handleAddPress : function(){
			this.byId("I_heartrate").setEditable(true);
			this.byId("I_temp").setEditable(true);
			this.byId("I_bloodpressure").setEditable(true);
			this.byId("btnSave").setEnabled(true)
		},*/
		
		handleSavePress : function(){
			this.byId("I_heartrate").setEditable(false);
			this.byId("I_temp").setEditable(false);
			this.byId("I_bloodpressure").setEditable(false);
		},
		
			
		editWeight :function(){
		    this.byId("I_weightage1").setEditable(true);
		},
		editWSave : function(){
		    this.byId("I_weightage1").setEditable(false);
		},
		editWeight1 :function(){
		    this.byId("I_weightage2").setEditable(true);
		},
		editWSave1 : function(){
		    this.byId("I_weightage2").setEditable(false);
		},
		onListItemPressed : function(oEvent){
			var oItem = oEvent.getSource();
			var parameters = oItem.getBindingContext().getProperty(oItem.getBindingContextPath());
			this.getView().getParent().to("idParam1",{parameters: parameters});
		},
		
		onDoctorsListPressed : function(oEvent){
			
			this.getView().getParent().to("idDoctorPatient1");
		},
		
		handleAddParameter : function(oEvent){
		    var odialog = new sap.ui.commons.Dialog();
		    odialog.setTitle("Add Parameters");
		    
		    //Create a matrix layout with 2 columns
             var oMatrix = new sap.ui.commons.layout.MatrixLayout({layoutFixed: true, width: '300px', columns: 2});
            oMatrix.setWidths('100px', '200px');

            //Create a header
             var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            oCell.addContent(new sap.ui.commons.TextView({text: 'Parameter', design: sap.ui.commons.TextViewDesign.H1}));
            oMatrix.createRow(oCell);

            //Create a form
            var oLabel = new sap.ui.commons.Label({text: 'Parameter Name'});
            var oInput = new sap.ui.commons.TextField({placeholder: 'Enter paremeter name', width: '100%'});
            oLabel.setLabelFor(oInput);
            oMatrix.createRow(oLabel, oInput);
            
            oLabel = new sap.ui.commons.Label({text: 'weightage'});
            oInput = new sap.ui.commons.TextField({placeholder: 'Enter weightage', width: '100%'});
            oLabel.setLabelFor(oInput);
            oMatrix.createRow(oLabel, oInput);
            
            //Create a standard divider
            var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            oCell.addContent(new sap.ui.commons.HorizontalDivider());
            oMatrix.createRow(oCell);
            
            //Create a button row
            var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            var oButton = new sap.ui.commons.Button({text: 'Save'});
            oButton.addStyleClass("CustomMargin"); //Add some additional left margin
            oCell.addContent(oButton);
            oButton = new sap.ui.commons.Button({text: 'Cancel'});
            oCell.addContent(oButton);
            oMatrix.createRow(oCell);
            
            // Attach the layout to the page
           

		    odialog.addContent(oMatrix);
		    odialog.addButton(new sap.ui.commons.Button({text: "OK", press:function(){odialog.close();}}));
         	odialog.open();
		    
		},
		
		handleAddDoctor : function(oEvent){
		var odialog = new sap.ui.commons.Dialog();
		    odialog.setTitle("Add Doctors");
		    
		    //Create a matrix layout with 2 columns
             var oMatrix = new sap.ui.commons.layout.MatrixLayout({layoutFixed: true, width: '300px', columns: 2});
            oMatrix.setWidths('100px', '200px');

            //Create a header
             var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            oCell.addContent(new sap.ui.commons.TextView({text: 'Doctor Assigned', design: sap.ui.commons.TextViewDesign.H1}));
            oMatrix.createRow(oCell);

            //Create a form
            var oLabel = new sap.ui.commons.Label({text: 'Name'});
            var oInput = new sap.ui.commons.TextField({placeholder: 'Enter doctors name', width: '100%'});
            oLabel.setLabelFor(oInput);
            oMatrix.createRow(oLabel, oInput);
            
            oLabel = new sap.ui.commons.Label({text: 'Phone Number'});
            oInput = new sap.ui.commons.TextField({placeholder: 'Enter phone number', width: '100%'});
            oLabel.setLabelFor(oInput);
            oMatrix.createRow(oLabel, oInput);
            
            //Create a standard divider
            var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            oCell.addContent(new sap.ui.commons.HorizontalDivider());
            oMatrix.createRow(oCell);
            
            //Create a button row
            var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
            var oButton = new sap.ui.commons.Button({text: 'Save'});
            oButton.addStyleClass("CustomMargin"); //Add some additional left margin
            oCell.addContent(oButton);
            oButton = new sap.ui.commons.Button({text: 'Cancel'});
            oCell.addContent(oButton);
            oMatrix.createRow(oCell);
            
            // Attach the layout to the page
           

		    odialog.addContent(oMatrix);
		    odialog.addButton(new sap.ui.commons.Button({text: "OK", press:function(){odialog.close();}}));
         	odialog.open();
		    
		},
		
		onChange: function(oEvent){
		    
		    var oItem = oEvent.getSource();
		    //arr.push(oItem._aInitialFocusRange); 
		 if(oItem.sId === "idprogram1--range-idprogram1--vid-0"){
          var sUrl = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs?min="+oItem._aInitialFocusRange[0]+"&max="+oItem._aInitialFocusRange[1]+"&param=1";
           }  
           else if(oItem.sId === "idprogram1--range-idprogram1--vid-1") {
               var sUrl = "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/range.xsjs?min="+oItem._aInitialFocusRange[0]+"&max="+oItem._aInitialFocusRange[1]+"&param=2";
           }
            var oRange = {};
         
         oRange.range = [ oItem._aInitialFocusRange[0], oItem._aInitialFocusRange[1]] ;
         
           /* oRange = arr;*/
            $.ajax({
                  type : "POST",
                  url : sUrl,
                 // data : JSON.stringify(oRange.innerHTML),
                  accept: "application/json",
                  //contentType = "application/json",
                  success : function(data, statusText, jqXHR) {
                        sap.ca.ui.message.showMessageToast("Parameters Modified", data);
                        //sap.ui.getCore().byId("idEditMyProfile").getParent().to("idMyProfile1");
                  },
                  error : function(oError) {
                        jQuery.sap.log.error("Parameters cannot be modified!");
                  }
            });
			
		}

	});
	return CController;
});
