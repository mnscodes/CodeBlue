sap.ui.define([ 'jquery.sap.global', 'sap/m/MessageToast',
		'sap/ui/core/Fragment', 'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter', 'sap/ui/model/json/JSONModel',
		'sap/ui/model/odata/v2/ODataModel' ], function(jQuery, MessageToast,
		Fragment, Controller, Filter, JSONModel) {
	"use strict";

	var CController = Controller.extend("masterdetails.index", {
		onInit : function() {
			var oModel = new JSONModel("./json/notification.json");
			var oDetails = this.getView().byId("Notification");
			oDetails.setModel(oModel);

			var oModel1 = new JSONModel("./json/notification.json");
			var oDetails1 = this.getView().byId("Notification2");
			oDetails1.setModel(oModel1);

			var oModel2 = new JSONModel("./json/notification.json");
			var oDetails2 = this.getView().byId("Notification3");
			oDetails2.setModel(oModel2);

		var oModel3 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/Patient_Details.xsjs?id=1");
				// oModel3 = new JSONModel("./json/patient2.json");
			var oDetails3 = this.getView().byId("ObjectPageLayout");
			oDetails3.setModel(oModel3);

	var oModel4 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/Patient_Details.xsjs?id=1");
	    //	var oModel4 = new JSONModel("./json/patient2.json");
			var oDetails4 = this.getView().byId("ObjectPageLayout2");
			oDetails4.setModel(oModel4);

			/*var oModel5 = new JSONModel("./json/patient.json");
			var oDetails5 = this.getView().byId("ObjectPageLayout3");
			oDetails5.setModel(oModel5);*/

			this.getSplitAppObj().setHomeIcon({
				'phone' : 'phone-icon.png',
				'tablet' : 'tablet-icon.png',
				'icon' : 'desktop.ico'
			});
		},

		gotoSeverity1Details : function(oEvent) {
			this.getSplitAppObj().to(this.createId("1"));
		},
		gotoSeverity2Details : function(oEvent) {
			this.getSplitAppObj().to(this.createId("2"));
		},
		gotoSeverity3Details : function(oEvent) {
			this.getSplitAppObj().to(this.createId("3"));
		},

		oncall : function() {
			sap.m.URLHelper.triggerTel("+919538108545");
		},

		onSMS : function() {
			sap.m.URLHelper.triggerSms("+919538108545");
		},

		getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		}

	});

	return CController;

});
