sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var view;
	var oController = Controller.extend("notification.Ambulance", {

		onInit: function() {
			view = this.getView();

			view.byId("SplitAppDemo").setHomeIcon({
				'phone': 'phone-icon.png',
				'tablet': 'tablet-icon.png',
				'icon': 'desktop.ico'
			});
			

			var omod=new sap.ui.model.json.JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/Patient_Notifcation.xsjs");

// 			var data_new = {
// 				'Patients': [{
// 					"Name": "Anand",
// 					"Gender": "Male",
// 					"Age": "45",
// 					"Contact": "8891322985",
// 					"EContact":"8971503189",
// 					"MedProgram": "Heart Patient",
// 					"Street": "Theodore Lowe ,Ap #867-859  39531 (793) 151-6230",
// 					"HouseNumber": "Sit Rd.Banglore",
// 					"ZIPCode": "560066",
// 					"City": "Bangalore",
// 					"state": true,
// 					"lat": "13.001621",
// 					"lng": "77.760215"
// 				}, {
// 					"Name": "Rajesh",
// 					"Gender": "Male",
// 					"Age": "35",
// 					"Contact": "988123456",
// 					"EContact":"8971503189",
// 					"MedProgram": "Heart Patient",
// 					"Street": "Theodore Lowe ,Ap #867-859 ",
// 					"HouseNumber": "Sit Rd.Banglore ",
// 					"ZIPCode": "560066",
// 					"City": "Bangalore",
// 					"state": false,
// 					"lat": "13.003200",
// 					"lng": "77.754217"
// 				}, {
// 					"Name": "Veena",
// 					"Gender": "Female",
// 					"Age": "60",
// 					"Contact": "9538108545",
// 					"EContact":"8971503189",
// 					"MedProgram": "Alzheimer",
// 					"Street": "Hiroko Potter P.O. Box 887 2508 ",
// 					"HouseNumber": "Dolor. Av. Muskegon KY 12482",
// 					"ZIPCode": "560066",
// 					"City": "Bangalore",
// 					"state": false,
// 					"lat": "13.002573",
// 					"lng": "77.750483"
// 				}]
// 			};
// 			omod.setData(data_new);
			view.setModel(omod);
			
		},

		onOrientationChange: function(oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			sap.m.MessageToast.show(sMsg, {
				duration: 5000
			});
		},

		handleListSelect: function(oEvent) {
			var dt= this.getView().byId("map").getDirections();
			if(dt)
			{
				dt.reset();
			}
			// sap.m.MessageToast.show("Master pressed");
			// this.navigation.navTo("idViewRoot--idViewDetail", oEvent.getParameter("listItem").getBindingContext());
			var oBindingContext = oEvent.getParameter("listItem").getBindingContext();
			this.getView().byId("SimpleFormDisplayPD").setBindingContext(oBindingContext);
			this.getView().byId("SimpleFormDisplayAdd").setBindingContext(oBindingContext);
			this.getView().byId("SimpleFormDisplayCB").setBindingContext(oBindingContext);
			this.getView().byId("ambas").setBindingContext(oBindingContext);
			this.getView().byId("mark1").setBindingContext(oBindingContext);
			var obc = this.getView().byId("ambas").getBindingContext();
			var index = obc.getPath().replace("/Patients/value/", "");
			var val=index.replace("/value/","");
			var id = "idAmbulance3--sli-idAmbulance3--idListPatient-" + val;
			var state = this.getView().byId("ambas").getState();
			if (state == true) {
				document.getElementById(id).style.backgroundColor = "#D3D3D3";
			}

			//Logic to dynamically get the value of time and distance from google map api
			var origin_lat = 13.000576;
			var origin_lng = 77.757564;
			var dest_lat = this.getView().byId("mark1").getBindingContext().getObject().lat;
			var dest_lng = this.getView().byId("mark1").getBindingContext().getObject().lng;
			var origin = {
				lat: 55.93,
				lng: -3.118
			};
			origin.lat = origin_lat;
			origin.lng = origin_lng;

			var destination = {
				lat: 55.93,
				lng: -3.118
			};
			destination.lat = parseFloat(dest_lat);
			destination.lng = parseFloat(dest_lng);
			
			//getiing directions logic
			var origin1=[];
			var destination1=[];
			origin1.push(origin_lat);
			origin1.push(origin_lng);
			destination1.push(destination.lat);
			destination1.push(destination.lng);
			var directions = new openui5.googlemaps.Directions({
    			startAddress: origin1,
    			endAddress: destination1,
    			travelMode: openui5.googlemaps.TravelMode.driving,
    			unitSystem: openui5.googlemaps.UnitSystem.IMPERIAL});
    		
    		var map =this.getView().byId("map").setDirections(directions);
    		
			
			// alert("check");
			var service = new google.maps.DistanceMatrixService;
			service.getDistanceMatrix({
				origins: [origin],
				destinations: [destination],
				travelMode: google.maps.TravelMode.DRIVING,
				unitSystem: google.maps.UnitSystem.METRIC,
				avoidHighways: false,
				avoidTolls: false
			}, function(response, status) {
				// alert("inside");
				if (status !== google.maps.DistanceMatrixStatus.OK) {
					// alert('Error was: ' + status);
				} else {
					// alert("Done!!");
					var oModel = new sap.ui.model.json.JSONModel();
					oModel = response;
					var distance = oModel.rows[0].elements[0].distance.text;
					var time = oModel.rows[0].elements[0].duration.text;
					document.getElementById("idAmbulance3--time").innerText = time;
					document.getElementById("idAmbulance3--distance").innerText = distance;
				}
			});

			// var key = "AIzaSyBe7ri9EbyNgM2-XijJYDdHDXSgNO43n1I";
			// var sUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=" + origin_lat + "," + origin_lng +
			// 	"&destinations=" + dest_lat + "," + dest_lng + "&key=" + key;
			// alert("code now");
			// var oModel = new sap.ui.model.json.JSONModel();
			// var aData = jQuery.ajax({
			// 	type: "GET",
			// 	contentType: "application/json",
			// 	url: sUrl,
			// 	// dataType: "json",
			// 	headers: {
			// 		"Access-Control-Allow-Origin": "*"
			// 	},
			// 	success: function(data, textStatus, jqXHR) {

			// 		oModel.setData({
			// 			modelData: data
			// 		});
			// 		sap.m.MessageToast.show("Success");
			// 	}

			// });

			// window.console.log(aData);
		},

		onPressAssignAmbulance: function(oEvent) {

			var obc = this.getView().byId("ambas").getBindingContext();
			var index = obc.getPath().replace("/Patients/value/", "");
			var val=index.replace("/value/","");
			
			var id = "idAmbulance3--sli-idAmbulance3--idListPatient-" + val ;
			var state = this.getView().byId("ambas").getState();
			if (state == true) {
				document.getElementById(id).style.backgroundColor = "#98FB98";
				sap.m.MessageToast.show("Ambulance is Assigned to Patient");
			} else {
				document.getElementById(id).style.backgroundColor = "white";
				sap.m.MessageToast.show("Ambulance is un-assigned to Patient");
			}
			var not_id=obc.getObject().Notification_Id;
		    var dev_id=obc.getObject().Device_id;
		    var ts=obc.getObject().TimeStamp;
		    var sUrl="https://sliblra7eac59ae.hana.ondemand.com:443/I315050/sliblr/MyPackage/services.xsodata/Notification(Notification_Id='"+not_id+"',Device_id='"+dev_id+"',TimeStamp='"+ts+"')";
		    var query =" { \"Action_taken\" : \"Ambulance assigned\",\"Status\" : \"attended\"}";
		    $.ajax({
                url: sUrl,
                //(Notification_Id='1',Device_id='1',TimeStamp='07%2F16%2F16%2015%3A05')
                dataType: "json",
                data: query,
                method: "PATCH",
                contentType :"application/json;",
                accept: "application/json;",
                beforeSend: function(xhr)  
                                          {  
                                                    xhr.setRequestHeader("X-CSRF-Token", "Fetch");  
                                          },  
               
                 success: function(data, textStatus, XMLHttpRequest){  
                      var resptext = XMLHttpRequest.responseText;  
                      jQuery.sap.require("sap.ui.commons.MessageBox");  
               	      var successMsg = "Your Message is updated and Notification is attended";
		              sap.m.MessageToast.show(successMsg);
            },
            error : function(e) {
        	var successMsg = "Call not successful updated";
		    sap.m.MessageToast.show(successMsg);
            } });

			
		},
		onPressSendDetails: function(oEvent) {
		   
		   sap.m.MessageToast.show("Details are updated"); 
		},
		
		onPressHome: function(oEvent) {
		   
		    this.getView().getParent().to("idTile1");
		}

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf CBlueFinal.view.Ambulance
		 *

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf CBlueFinal.view.Ambulance
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf CBlueFinal.view.Ambulance
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf CBlueFinal.view.Ambulance
		 */
		//	onExit: function() {
		//
		//	}
    
	});
  return oController;
});