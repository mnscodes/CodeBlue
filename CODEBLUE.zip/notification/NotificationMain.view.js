sap.ui.jsview("notification.NotificationMain", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf notification.NotificationMain
	*/ 
	getControllerName : function() {
		return "notification.NotificationMain";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf notification.NotificationMain
	*/ 
	createContent : function(oController) {
		var oSplitterV = new sap.ui.commons.Splitter("splitterV");
		oSplitterV.setSplitterOrientation(sap.ui.commons.Orientation.vertical);
		oSplitterV.setSplitterPosition("20%");
		oSplitterV.setMinSizeFirstPane("20%");
		oSplitterV.setMinSizeSecondPane("30%");
		oSplitterV.setWidth("100%");
 		return new sap.m.Page({
			title: "Code Blue",
			content: [oSplitterV
			
			]
		});
	}

});