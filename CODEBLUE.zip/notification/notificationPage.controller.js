sap.ui.define([ 'jquery.sap.global', 'sap/m/MessageToast',
		'sap/ui/core/Fragment', 'sap/ui/core/mvc/Controller','sap/m/List',
		'sap/m/StandardListItem','sap/m/MessageBox',
		'sap/ui/model/Filter', 'sap/ui/model/json/JSONModel',
		'sap/ui/model/odata/v2/ODataModel' ], function(jQuery, MessageToast,
		Fragment, Controller,List,StandardListItem,MessageBox, Filter, JSONModel) {
	"use strict";
	
       	var oModel1;
       	var oModel;
	    var CController = sap.ui.controller("notification.notificationPage", {
		
		onInit : function() {
			oModel = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Notification?$filter=Status%20eq%20%27Open%27%20&$orderby=Severity&$format=json");
			var oDetails = this.getView().byId("Notificationlist");
			oDetails.setModel(oModel);
			this.getView().setModel(oModel,"NotificationList");
		},
		
	    onBeforeRendering: function() {
	       /* oModel.refresh(true);
	        oModel1.refresh(true);*/
	        oModel = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Notification?$filter=Status%20eq%20%27Open%27%20&$orderby=Severity&$format=json");
			var oDetails = this.getView().byId("Notificationlist");
			oDetails.setModel(oModel);
			//this.getView().setModel(oModel,"NotificationList");
            var temp = this.getView().getModel("NotificationList");
            var notification1=  temp.getProperty("/d/results/0");
            var id = notification1.Notification_Id;
            var severity = notification1.Severity;
			oModel1 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/Patient_Details.xsjs?id="+id);
			oModel1.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			var oPatient = this.getView().byId("ObjectPageLayout");
			oPatient.setModel(oModel1);
			this.getView().setModel(oModel1,"NotificationDetail");
			if(severity < 2 ){
	       this.getSplitAppObj().to(this.createId("1"));
			}else {
			this.getSplitAppObj().to(this.createId("2"));
			}
	        sap.ui.getCore().setModel(oModel1);
     	},
	
	    gotoSeverityDetails: function(oEvent){
	    
	        var  oModel = oEvent.getSource();
            var  notification = oModel.getBindingContext().getProperty(oModel.getBindingContextPath());
            var current = notification.Notification_Id;
            oModel1 = new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/Patient_Details.xsjs?id="+current);
            oModel1.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
            var oPatient1 = this.getView().byId("ObjectPageLayout2");
			oPatient1.setModel(oModel1);
			this.getView().setModel(oModel1,"NotificationDetail");
			if(notification.Severity < 2 ){
	       this.getSplitAppObj().to(this.createId("1"));
			}else {
			this.getSplitAppObj().to(this.createId("2"));
			}
	        },
	        
	    getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		    },
		    
		    handleInfoMessage: function(){
	        var bcompact =!!this.getView().$().closest(".sapUiSizeCompact").length;
	        MessageBox.information("Message is sent successfully",{styleClass: bcompact? "sapUiSizeCompact":""});
	    },
		
		oncall: function(){
		    var temp = this.getView().getModel("NotificationDetail");
            var Doctorno =  temp.getProperty("/Doctor Ph No");
            Doctorno = "+91"+Doctorno;
            var patientno= temp.getProperty("/Contact_Number");
            patientno = "+91"+patientno;
            var emNo = temp.getProperty("/Emergency_Contact_1");
            emNo = "+91"+emNo;
            var emNo1 = temp.getProperty("/Emergency_Contact_2");
            emNo1 = "+91"+emNo1;
			var dialog = new sap.m.Dialog({
				title: "Phone Numbers",
				content: new List({
					items: [
						new StandardListItem({id:"list1",
							title: "Doctor Number",
							description: Doctorno,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(Doctorno); 
							}
						}),new StandardListItem({id:"list2",
							title: "Patient Number",
							description:patientno,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(patientno); 
							}
						}),new StandardListItem({id:"list3",
							title: "Emergency Number",
							description:emNo,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(emNo); 
							}
						}),new StandardListItem({id:"list4",
							title: "Emergency Number",
							description:emNo1,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(emNo1); 
							}
						})]
				}),
		
				beginButton: new sap.m.Button({
					text: 'Close',
					press: function () {
						dialog.close();
					}
				}),
				
				afterClose: function() {
				    var oController = sap.ui.getCore().byId("idNotification2").getController();
                     oController.onConfirm(temp.getProperty("/Notification_Id"),temp.getProperty("/Device_id"),temp.getProperty("/TimeStamp"));
					dialog.destroy();
					
				}
			});
		
			this.getView().addDependent(dialog);
			dialog.open();
		},
		
			textBoxForSMS: function(number){
			   
                var oMatrix = new sap.ui.commons.layout.MatrixLayout({layoutFixed: true, width: '300px', columns: 2});
                    oMatrix.setWidths('100px', '200px');


                var oLabel = new sap.ui.commons.Label({text: 'Recipient'});
                var oInput = new sap.ui.commons.TextField({value: number, width: '100%'});
                oLabel.setLabelFor(oInput);
                oMatrix.createRow(oLabel, oInput);

                var oLabel2 = new sap.ui.commons.Label({text: 'Message'});
                var oInput2 = new sap.ui.commons.TextArea('input2');
                oInput2.setValue("");
                oInput2.setTooltip("Message");
                oInput2.setRows(6);
                oInput2.setWidth("100%");
                oLabel2.setLabelFor(oInput);
                oMatrix.createRow(oLabel2, oInput2);


                var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
                oCell.addContent(new sap.ui.commons.HorizontalDivider());
                oMatrix.createRow(oCell);

			    var dialog3 = new sap.m.Dialog({
				title: "Message Box",
				content: [oMatrix],
				beginButton: new sap.m.Button({
					text: 'Send',
					press: function () {
						dialog3.close();
					}
				}),
				
				afterClose: function() {
				
				   var oController = sap.ui.getCore().byId("idNotification2").getController();
                     oController.handleInfoMessage();
                     	dialog3.destroy();
				}
			});
			//to get access to the global model
			this.getView().addDependent(dialog3);
			dialog3.open();
		},
	
		
		
		onSMS: function(){
		    var temp = this.getView().getModel("NotificationDetail");
            var Doctorno =  temp.getProperty("/Doctor Ph No");
            Doctorno = "+91"+Doctorno;
            var patientno= temp.getProperty("/Contact_Number");
            patientno = "+91"+patientno;
            var emNo = temp.getProperty("/Emergency_Contact_1");
            emNo = "+91"+emNo;
            var emNo1 = temp.getProperty("/Emergency_Contact_2");
            emNo1 = "+91"+emNo1;
			var dialog1 = new sap.m.Dialog({
				title: "Phone Numbers",
				content: new List({
					items: [
						new StandardListItem({id:"list11",
							title: "Doctor Number",
							description: Doctorno,
							type: "Navigation",
							press: function(){
							 var oController = sap.ui.getCore().byId("idNotification2").getController();
							  oController.textBoxForSMS(Doctorno); 
							}
						}),new StandardListItem({id:"list21",
							title: "Patient Number",
							description:patientno,
							type: "Navigation",
							press: function(){
							  var oController = sap.ui.getCore().byId("idNotification2").getController();
							  oController.textBoxForSMS(patientno); 
							}
						}),new StandardListItem({id:"list31",
							title: "Emergency Number",
							description:emNo,
							type: "Navigation",
							press: function(){
							  var oController = sap.ui.getCore().byId("idNotification2").getController();
							  oController.textBoxForSMS(emNo); 
							}
						}),new StandardListItem({id:"list41",
							title: "Emergency Number",
							description:emNo1,
							type: "Navigation",
							press: function(){
							  var oController = sap.ui.getCore().byId("idNotification2").getController();
							  oController.textBoxForSMS(emNo1); 
							}
						})]
				}),
		
				beginButton: new sap.m.Button({
					text: 'Close',
					press: function () {
						dialog1.close();
					}
				}),
				
				afterClose: function() {
				   /* var oController = sap.ui.getCore().byId("idNotification2").getController();
                     oController.onConfirm(temp.getProperty("/Notification_Id"),temp.getProperty("/Device_id"),temp.getProperty("/TimeStamp"));*/
					dialog1.destroy();
				}
			});
			this.getView().addDependent(dialog1);
			dialog1.open();
		},
		
		onConfirm: function(notification_id,deviceid,timestamp){
                var oMatrix = new sap.ui.commons.layout.MatrixLayout({layoutFixed: true, width: '300px', columns: 2});
                    oMatrix.setWidths('110px', '200px');
                  
                  var oLabel = new sap.ui.commons.Label({text: 'Device'});
                  var oInput = new sap.ui.commons.TextField({id:'oinput1', value: notification_id, width:'100%'});
                  oInput.setEditable(false);
                  oLabel.setLabelFor(oInput);
                
                var oLabel2 = new sap.ui.commons.Label({text: 'Message'});
                var oInput2 = new sap.ui.commons.TextArea('input2');
                oInput2.setValue("");
                oInput2.setTooltip("Message");
                oInput2.setRows(6);
                oInput2.setWidth("100%");
                oInput2.setEditable(false);
                oLabel2.setLabelFor(oInput);
                
                    var oRB1 = new sap.ui.commons.RadioButton({
                        id: 'Radio',
	                   text : 'Call Happened',
	                   tooltip : 'Select for Yes',
	                   groupName : 'Group1',
		               select : function() {
		                   oInput.setEditable(true);
		                   oInput2.setEditable(true);
		                   
		               }
	                     });
	                     oRB1.setWidth("600Px");
	                oMatrix.createRow(oRB1);
                  oMatrix.createRow(oLabel2, oInput2);

                var oCell = new sap.ui.commons.layout.MatrixLayoutCell({colSpan: 2});
                oCell.addContent(new sap.ui.commons.HorizontalDivider());
                oMatrix.createRow(oCell);
                
                
			    var dialog2 = new sap.m.Dialog({
				title: "Phone Numbers",
				content: [oMatrix],
				beginButton: new sap.m.Button({
					text: 'Send',
					press: function () {
		                var oController = sap.ui.getCore().byId("idNotification2").getController();
							  oController.updateActionTaken(notification_id, deviceid,timestamp,oInput2.getValue()); 
						dialog2.close();
					}
				}),
				afterClose: function() {
					dialog2.destroy();
				}
			});
			
			this.getView().addDependent(dialog2);
			dialog2.open();
		},
		
		updateActionTaken: function(id,deviceid,ts,actionNote){
		    var query =" { \"Action_taken\" : \""+actionNote+"\",\"Status\" : \"attended\"}";
             
			$.ajax({
                url: "https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Notification(Notification_Id=\'"+id+"\',Device_id=\'"+deviceid+"\',TimeStamp=\'"+ts+"\')",
                //(Notification_Id='1',Device_id='1',TimeStamp='07%2F16%2F16%2015%3A05')
                dataType: "json",
                data: query,
                method: "PATCH",
                contentType :"application/json;",
                accept: "application/json;",
                beforeSend: function(xhr)  
                                          {  
                                                    xhr.setRequestHeader("X-CSRF-Token", "Fetch");  
                                          },  
               
                 success: function(data, textStatus, XMLHttpRequest){  
                      var resptext = XMLHttpRequest.responseText;  
                      jQuery.sap.require("sap.ui.commons.MessageBox");  
               	      var successMsg = "Your Message is updated and Notification is attended";
		              sap.m.MessageToast.show(successMsg);
            },
            error : function(e) {
        	var successMsg = "Call not successful updated";
		    sap.m.MessageToast.show(successMsg);
            } });

		},
		
		onBtnHome : function(){
			this.getView().getParent().to("idTile1");
		},
		
		
		callAmbulance: function(){
		  //   sap.ui.getCore().setModel(oModel1,"id");
		    	this.getView().getParent().to("idAmbulance3");
		},
		
		verify: function(){
		    var temp = this.getView().getModel("NotificationDetail");
            var Doctorno =  temp.getProperty("/Doctor Ph No");
            Doctorno = "+91"+Doctorno;
            var patientno= temp.getProperty("/Contact_Number");
            patientno = "+91"+patientno;
            var emNo = temp.getProperty("/Emergency_Contact_1");
            emNo = "+91"+emNo;
            var emNo1 = temp.getProperty("/Emergency_Contact_2");
            emNo1 = "+91"+emNo1;
			var dialog = new sap.m.Dialog({
				title: "Phone Numbers",
				content: new List({
					items: [
						new StandardListItem({id:"list1",
							title: "Doctor Number",
							description: Doctorno,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(Doctorno); 
							}
						}),new StandardListItem({id:"list2",
							title: "Patient Number",
							description:patientno,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(patientno); 
							}
						}),new StandardListItem({id:"list3",
							title: "Emergency Number",
							description:emNo,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(emNo); 
							}
						}),new StandardListItem({id:"list4",
							title: "Emergency Number",
							description:emNo1,
							type: "Navigation",
							press: function(){
							   sap.m.URLHelper.triggerTel(emNo1); 
							}
						})]
				}),
		
				beginButton: new sap.m.Button({
					text: 'Close',
					press: function () {
						dialog.close();
					}
				}),
				
				afterClose: function() {
					dialog.destroy();
					
				}
			});
		
			this.getView().addDependent(dialog);
			dialog.open();
		}
		

	});

	return CController;
});