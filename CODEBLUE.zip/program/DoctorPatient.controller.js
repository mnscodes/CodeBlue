sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'./Formatter',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, MessageToast, Formatter, Controller, JSONModel) {
	"use strict";

	var ListController = Controller.extend("program.DoctorPatient", {

		onInit: function () {
			// set explored app's demo model on this sample
			//var dataset = "./program/dataset";
			
			var oC = this;
		 
		 oC.getView().addEventDelegate({
			 onBeforeShow : function(evt){
			     var id = evt.data.patientId.Doctor_Id;
				 oC.getView().byId("PatientsList").setModel(new JSONModel("https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/doctor.xsjs?Doctor_Id="+id));
			 }
		 });
		},
	
		
		onNavBack : function() {
			this.getView().getParent().to("idprogram1");
		}
		
	});


	return ListController;

});