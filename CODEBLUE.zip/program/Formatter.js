sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status :  function (sStatus) {
				if (sStatus === "Issued") {
					return "Success";
				} else if (sStatus === "Not Issued"){
					return "Error";
				} else {
					return "None";
				}
		}
	};

	return Formatter;

}, /* bExport= */ true);
