sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter',
		'sap/ui/model/json/JSONModel',
		'sap/viz/ui5/controls/common/feeds/FeedItem',
        'sap/viz/ui5/data/FlattenedDataset',
        'sap/viz/ui5/format/ChartFormatter',
        './ControllerOverall'
	], function(jQuery, MessageToast, Fragment, Controller, Filter, JSONModel, FeedItem, FlattenedDataset, ChartFormatter, ControllerOverall) {
	"use strict";

	var CController = Controller.extend("program.Param", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf dapp.Views.Login
	 */
	 onInit: function() {
		 
		 
		/* var oData= {
			RS1:[60,190],
			RS2:[]
				 
		 };
		 var oModel = new JSONModel(oData);
		 this.getView().setModel(oModel);*/
		 
		 var oC = this;
		 
		 oC.getView().addEventDelegate({
			 onBeforeShow : function(evt){
//				 var dataset = "./program/dataset",
//				 selectedObj = {};
//				 
//				 $.ajax({
//					 url: dataset + "/param.json",
//					 type: "GET",
//					 success: function(data) {
//						 data.program.forEach(function(program){
//							 if(program["Parameter Id"] === evt.data.ParameterId) {
//								 selectedObj = program;
//							 }
//						 });
//						 
//						 var oForm = oC.getView().byId("form");
//						 oForm.setModel(new JSONModel(selectedObj));
//					 },
//					 error: function(err) {
//						 console.error(err);
//					 }
//				 });
				 
				 oC.getView().byId("form").setModel(new JSONModel(evt.data.parameters));
			 }
			 
			
		 });
		 
		 
	 },
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the
	 * controller's View is re-rendered (NOT before the first rendering!
	 * onInit() is used for that one!).
	 * 
	 * @memberOf dapp.Views.Login
	 */
	// onBeforeRendering: function() {
	//
	// },
	/**
	 * Called when the View has been rendered (so its HTML is part of the
	 * document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * 
	 * @memberOf dapp.Views.Login
	 */
	// onAfterRendering: function() {
	//
	// },
	/**
	 * Called when the Controller is destroyed. Use this one to free resources
	 * and finalize activities.
	 * 
	 * @memberOf dapp.Views.Login
	 */
	// onExit: function() {
	//
	// }
	
	onNavBack : function() {
		this.getView().getParent().to("idprogram1");
	}
	
	});
	
	return CController;
	
});






