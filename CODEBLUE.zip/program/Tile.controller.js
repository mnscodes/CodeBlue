sap.ui.define(['jquery.sap.global', 'sap/ui/core/mvc/Controller'],
	function(jQuery, Controller) {
	"use strict";

	var PageController = Controller.extend("program.Tile", {
		press : function() {
			this.getView().getParent().to("idprogram1");
		},
		onBtnLogOut : function() {
			this.getView().getParent().to("idLogin1");
		},
		
		notifications: function(oEvent){
		    
		this.getView().getParent().to("idNotification2");
	},
	
		onAfterRendering: function() {
     var result ;
    self=this;
       $.ajax({
                                                     
                                                     url:"https://sliblra7eac59ae.hana.ondemand.com/I315050/sliblr/MyPackage/services.xsodata/Notification?$select=Status&$filter=Status eq 'Open'&$format=json",
                                                     method: "GET",
                                                     accept : "application/json",
                                                     contentType :"application/json",
                                                     success:function(data)
                                                     {
                                                      result= data;
                                                     // var temp = "This is a string.";
                                                        var count = 0;
                                                        count = result.d.results.length;

                                                      //if(count)
                                                      self.getView().byId("temp").setValue(count);
                                                   //   alert(result);
                                                     },
                                                     failure : function()
                                                     {
                                                         
                                                     }
                                                  });
	},
		Patient : function(evt) {
			this.getView().getParent().to("idEntry1");
		} 
		
	});

	return PageController;
});